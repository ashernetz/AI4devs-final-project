import React, { useState } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Menu,
  MenuItem,
  Button,
  Box,
} from '@mui/material';
import { Menu as MenuIcon } from '@mui/icons-material';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar: React.FC = () => {
  const { role, logout } = useAuth(); // Accedemos al rol del usuario
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const handleMenuClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <>
      <AppBar position="fixed">
        <Toolbar>
          <IconButton
            edge="start"
            color="inherit"
            aria-label="menu"
            onClick={handleMenuClick}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Restaurant Management
          </Typography>
          <Button color="inherit" onClick={handleLogout}>
            Logout
          </Button>
        </Toolbar>
      </AppBar>

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem
          component={RouterLink}
          to="/dashboard"
          onClick={handleMenuClose}
        >
          Dashboard
        </MenuItem>

        {/* Opciones condicionales según el rol del usuario */}
        {role === 'superadmin' && (
          <>
            <MenuItem
              component={RouterLink}
              to="/restaurants"
              onClick={handleMenuClose}
            >
              Restaurants
            </MenuItem>
            <MenuItem
              component={RouterLink}
              to="/categories"
              onClick={handleMenuClose}
            >
              Categories
            </MenuItem>
          </>
        )}

        {(role === 'superadmin' || role === 'owner' || role === 'admin') && (
          <>
            <MenuItem
              component={RouterLink}
              to="/products"
              onClick={handleMenuClose}
            >
              Products
            </MenuItem>
            <MenuItem
              component={RouterLink}
              to="/employees"
              onClick={handleMenuClose}
            >
              Employees
            </MenuItem>
            <MenuItem
              component={RouterLink}
              to="/orders"
              onClick={handleMenuClose}
            >
              Orders
            </MenuItem>
          </>
        )}
      </Menu>
    </>
  );
};

export default Navbar;
