import { useState, CSSProperties } from 'react';
import ClipLoader from 'react-spinners/ClipLoader';
const override: CSSProperties = {
  display: 'block',
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
};

const Spinner = ({ loading }: any) => {
  return (
    <div className="sweet-loading">
      <ClipLoader
        color={'#123abc'}
        loading={loading}
        cssOverride={override}
        size={150}
        aria-label="Loading Spinner"
        data-testid="loader"
      />
    </div>
  );
};

export default Spinner;
