import React, { forwardRef } from 'react';
import {
  Link as RouterLink,
  LinkProps as RouterLinkProps,
} from 'react-router-dom';

// Crear el componente de Link personalizado usando forwardRef
const CustomLink = forwardRef<
  HTMLAnchorElement,
  Omit<RouterLinkProps, 'to'> & { to: string }
>(function CustomLink(props, ref) {
  return <RouterLink ref={ref} {...props} />;
});

export default CustomLink;
