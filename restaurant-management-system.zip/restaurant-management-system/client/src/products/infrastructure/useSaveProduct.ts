import { useMutation } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { useState } from 'react';
import { ProductFormData } from '../domain/product.interface';

const useSaveProduct = () => {
  const [isLoading, setIsLoading] = useState(false);
  const mutation = useMutation({
    mutationFn: (params: ProductFormData) =>
      apiClient.post('/product/register', params),

    onSettled: () => {
      setIsLoading(false);
    },
  });
  const postProduct = async (productData: {
    price: number | '';
    name: string;
    description: string;
    restaurantId: string | null;
    categoryId: string;
  }) => {
    setIsLoading(true);
    // @ts-ignore
    return mutation.mutateAsync(productData);
  };

  return {
    isLoading,
    mutate: postProduct,
    isError: mutation.isError,
  };
};
export default useSaveProduct;
