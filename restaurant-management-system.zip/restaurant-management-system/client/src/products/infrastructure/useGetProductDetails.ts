import { useQuery, useMutation } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { useState } from 'react';

interface iGetProductDetails {
  id: string;
  restaurantId: string;
}
const useGetProductDetails = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [productData, setProductData] = useState<any>(null);
  const mutation = useMutation({
    mutationFn: (params: any) => apiClient.post('/product/details', params),
    onSettled: (response) => {
      setIsLoading(false);
      setProductData(response?.data);
    },
  });
  const fetchProductDetails = async ({
    id,
    restaurantId,
  }: iGetProductDetails) => {
    setIsLoading(true);
    return mutation.mutateAsync({ id, restaurantId });
  };

  return {
    isLoading,
    productData,
    mutate: fetchProductDetails,
    isError: mutation.isError,
  };
};

export default useGetProductDetails;
