import { useQuery, useMutation } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { useState } from 'react';

interface IGetProduct {
  restaurantId: string;
  role: string;
}
const useGetProducts = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [productsData, setProductsData] = useState<any>(null);
  const mutation = useMutation({
    mutationFn: (params: any) => apiClient.post('/product', params),
    onSettled: (response) => {
      setIsLoading(false);
      setProductsData(response?.data);
    },
  });

  const fetchProducts = async (restaurantId: string) => {
    setIsLoading(true);
    return mutation.mutateAsync({ restaurantId });
  };

  return {
    isLoading,
    productsData,
    mutate: fetchProducts,
    isError: mutation.isError,
  };
};

export default useGetProducts;
