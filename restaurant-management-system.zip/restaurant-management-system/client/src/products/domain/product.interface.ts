export interface ProductFormData {
  restaurantId: string;
  name: string;
  price: string | null;
  categoryId: string;
  description: string;
}

export interface IProduct {
  _id: string;
  name: string;
  price: number;
  description: string;
  categoryId: string;
}
