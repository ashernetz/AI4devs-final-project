import React, { useState } from 'react';
import {
  TextField,
  Button,
  Container,
  Box,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useRestaurant } from '../../context/RestaurantContext';
import useSaveProduct from '../infrastructure/useSaveProduct';
import toast from 'react-hot-toast';
import useCategoriesApi from '../../categories/infrastructure/useGetCategories';
import Spinner from '../../components/Spinner'; // Para notificaciones

const ProductForm = () => {
  const { role } = useAuth();
  const { selectedRestaurantId } = useRestaurant();
  const [name, setName] = useState('');
  const [price, setPrice] = useState<number | ''>('');
  const [description, setDescription] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const navigate = useNavigate();

  // @ts-ignore
  const {
    mutate: postProduct,
    isLoading: isLoadingPost,
    isError,
  } = useSaveProduct();
  const {
    isLoading: isLoadingCategories,
    data: categories,
    error: categoriesError,
  } = useCategoriesApi();
  console.log('categories', categories);
  const isLoading = isLoadingCategories || isLoadingPost;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      postProduct({
        name,
        price,
        description,
        categoryId,
        restaurantId: selectedRestaurantId,
      });
      toast.success('Product created successfully');
      cleanForm();
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  const cleanForm = () => {
    setName('');
    setPrice('');
    setDescription('');
    setCategoryId('');
  };

  if (isLoading) return <Spinner isLoading={isLoading} />;

  return (
    <Container component="main" maxWidth="sm">
      <Box sx={{ mt: 8 }}>
        <Typography component="h1" variant="h5">
          Add New Product
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            margin="normal"
            required
            fullWidth
            label="Product Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            label="Price"
            type="string"
            value={price}
            onChange={(e) => setPrice(e.target.value as unknown as number)}
          />
          <FormControl fullWidth margin="normal">
            <InputLabel id="category-select-label">Category</InputLabel>
            <Select
              labelId="category-select-label"
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              label="Category"
            >
              {categories!.map((category) => (
                <MenuItem key={category._id} value={category._id}>
                  {category.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField
            margin="normal"
            required
            fullWidth
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            multiline
            rows={4}
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            disabled={isLoading}
            sx={{ mt: 3 }}
          >
            {isLoading ? 'Saving...' : 'Create Product'}
          </Button>
        </form>
      </Box>
    </Container>
  );
};

export default ProductForm;
