import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Card,
  CardContent,
  Typography,
  Button,
  CircularProgress,
  Box,
  CardActions,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import useGetProductDetails from '../infrastructure/useGetProductDetails';
import apiClient from '../../services/axios';
import { useRestaurant } from '../../context/RestaurantContext';
import Spinner from '../../components/Spinner';

interface IProduct {
  _id: string;
  name: string;
  price: number;
  description: string;
  categoryId: string;
}

const ProductDetails: React.FC = () => {
  const { id: productId } = useParams<{ id: string }>(); // Obtener el ID del producto desde la URL
  const { selectedRestaurantId } = useRestaurant();
  const navigate = useNavigate();

  const {
    mutate: fetchProductDetails,
    isError,
    isLoading,
    productData,
  } = useGetProductDetails();

  useEffect(() => {
    if (productId && selectedRestaurantId) {
      fetchProductDetails({
        id: productId,
        restaurantId: selectedRestaurantId,
      });
    }
  }, [productId, selectedRestaurantId]);

  if (isLoading) {
    return <Spinner isLoading={isLoading} />;
  }

  if (!productData || isError) {
    return <Typography color="error">Product not found.</Typography>;
  }

  return (
    <Card sx={{ maxWidth: 600, margin: 'auto', mt: 5, p: 2 }}>
      <CardContent>
        <Typography variant="h5" component="div" gutterBottom>
          {productData.name}
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Price: ${productData.price}
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Category ID: {productData.categoryId}
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Description: {productData.description}
        </Typography>
      </CardContent>

      <CardActions>
        <Button
          variant="outlined"
          color="primary"
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate(-1)} // Volver a la página anterior
        >
          Back
        </Button>
      </CardActions>
    </Card>
  );
};

export default ProductDetails;
