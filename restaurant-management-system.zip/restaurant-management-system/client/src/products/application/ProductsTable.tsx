import React, { useEffect } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Button,
  Box,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useRestaurant } from '../../context/RestaurantContext';
import Spinner from '../../components/Spinner';
import { useAuth } from '../../context/AuthContext';
import useGetProducts from '../infrastructure/useGetProducts';

interface IProduct {
  _id: string;
  name: string;
  price: number;
  description: string;
  categoryId: string;
}

const ProductTable: React.FC = () => {
  const { selectedRestaurantId } = useRestaurant(); // Obtener el restaurante seleccionado del contexto
  const { role } = useAuth();
  const {
    mutate: fetchProducts,
    isError,
    isLoading,
    productsData,
  } = useGetProducts();
  const navigate = useNavigate();

  useEffect(() => {
    if (selectedRestaurantId && role) {
      fetchProducts(selectedRestaurantId);
    }
  }, [selectedRestaurantId, role]);

  if (isLoading) {
    return <Spinner loading={isLoading} />;
  }

  if (isError || !productsData) {
    return <Typography color="error">Error loading products.</Typography>;
  }

  return (
    <Box sx={{ position: 'relative', paddingBottom: '80px' }}>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} aria-label="product table">
          <TableHead>
            <TableRow>
              <TableCell>
                <Typography variant="h6">Product Name</Typography>
              </TableCell>
              <TableCell align="right">
                <Typography variant="h6">Price</Typography>
              </TableCell>
              <TableCell align="right">
                <Typography variant="h6">Category ID</Typography>
              </TableCell>
              <TableCell align="right">
                <Typography variant="h6">Actions</Typography>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {productsData.map((product: IProduct) => (
              <TableRow
                key={product._id}
                sx={{
                  cursor: 'pointer',
                  '&:hover': { backgroundColor: '#f5f5f5' },
                }}
              >
                <TableCell component="th" scope="row">
                  {product.name}
                </TableCell>
                <TableCell align="right">{product.price}</TableCell>
                <TableCell align="right">{product.categoryId}</TableCell>
                <TableCell align="right">
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => navigate(`/products/${product._id}`)}
                    sx={{ mr: 1 }}
                  >
                    View Details
                  </Button>
                  <Button
                    variant="outlined"
                    color="secondary"
                    onClick={() => navigate(`/products/edit/${product._id}`)}
                  >
                    Edit
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Botón para agregar nuevo producto */}
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', marginTop: 3 }}>
        <Button
          variant="contained"
          color="primary"
          onClick={() => navigate('/products/new')}
        >
          Add Product
        </Button>
      </Box>
    </Box>
  );
};

export default ProductTable;
