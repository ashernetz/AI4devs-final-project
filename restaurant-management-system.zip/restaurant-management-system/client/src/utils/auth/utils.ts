const roles = ['superadmin', 'owner', 'admin', 'manager'];
export const hasRole = (role: string): boolean => roles.includes(role);
