import React from 'react';
import { Container, Typography, Box } from '@mui/material';
import LogoutLink from '../../auth/application/LogOut';

const Dashboard = () => {
  return (
    <Container component="main" maxWidth="lg">
      <Box sx={{ marginTop: 8 }}>
        <Typography component="h1" variant="h4">
          Dashboard
        </Typography>
        <Typography component="p" variant="body1">
          Bienvenido al panel de administración.
        </Typography>
        {/* Aquí puedes agregar más componentes e información relevante para el Dashboard */}
        <LogoutLink />
      </Box>
    </Container>
  );
};

export default Dashboard;
