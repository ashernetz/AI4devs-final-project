import React, { createContext, useContext, useState, ReactNode } from 'react';

interface RestaurantContextProps {
  selectedRestaurantId: string | null;
  storeRestaurantId: (id: string) => void;
}

const RestaurantContext = createContext<RestaurantContextProps | undefined>(
  undefined,
);

export const useRestaurant = () => {
  const context = useContext(RestaurantContext);
  if (!context) {
    throw new Error('useRestaurant must be used within a RestaurantProvider');
  }
  return context;
};

export const RestaurantProvider = ({ children }: { children: ReactNode }) => {
  const [selectedRestaurantId, setSelectedRestaurantId] = useState<
    string | null
  >(() => {
    return localStorage.getItem('restaurantId') || null;
  });

  const storeRestaurantId = (restaurantId: string | null) => {
    if (restaurantId) {
      setSelectedRestaurantId(restaurantId);
      localStorage.setItem('restaurantId', restaurantId); // Guardar en localStorage
    } else {
      setSelectedRestaurantId(null);
      localStorage.removeItem('restaurantId'); // Eliminar de localStorage si es null
    }
  };

  return (
    <RestaurantContext.Provider
      value={{ selectedRestaurantId, storeRestaurantId }}
    >
      {children}
    </RestaurantContext.Provider>
  );
};
