import React, { ReactNode } from 'react';
import { AuthProvider } from './AuthContext';
import { RestaurantProvider } from './RestaurantContext';
interface AppProvidersProps {
  children: ReactNode;
}

const AppProviders: React.FC<AppProvidersProps> = ({ children }) => {
  return (
    <AuthProvider>
      <RestaurantProvider>{children}</RestaurantProvider>
    </AuthProvider>
  );
};

export default AppProviders;
