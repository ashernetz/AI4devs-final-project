import {
  createContext,
  useState,
  useEffect,
  ReactNode,
  useContext,
} from 'react';
import apiClient from '../services/axios';
import { useMutation } from '@tanstack/react-query';
import { LoginSuccessResponse, User } from '../auth/domain/User.interface';

interface AuthContextProps {
  isAuthenticated: boolean;
  login: (email: string, password: string) => void;
  logout: () => void;
  token?: string | null;
  role?: string | null;
  userId?: string | null;
}

interface LoginData {
  email: string;
  password: string;
}

const AuthContext = createContext<AuthContextProps | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [token, setToken] = useState<string | null>(
    localStorage.getItem('authToken'),
  );
  const [isAuthenticated, setIsAuthenticated] = useState(!!token);
  const [role, setRole] = useState<string | null>(localStorage.getItem('role'));
  const [userId, setUserId] = useState<string | null>(
    localStorage.getItem('userId'),
  );
  const loginMutation = async ({ email, password }: LoginData) => {
    console.log('email', email);
    console.log('password', password);

    const response = await apiClient.post('/users/login', {
      email,
      password,
    });
    console.log('response', response.data);
    return response.data;
  };

  const mutation = useMutation({
    // @ts-ignore
    mutationFn: loginMutation,

    onSuccess: (data: LoginSuccessResponse) => {
      console.log('data', data);
      // Guardar el token en el localStorage y actualizar el estado
      localStorage.setItem('authToken', data.token);
      localStorage.setItem('role', data.user.role);
      localStorage.setItem('userId', data.user._id as string);
      localStorage.setItem(
        'user',
        JSON.stringify({ id: data.user._id, role: data.user.role }),
      );
      //setToken(data.token);
      setIsAuthenticated(true);
      // Redirigir al Dashboard o cualquier página después del login
      window.location.href = '/dashboard';
    },
    onError: (error: Error) => {
      console.error('Error al iniciar sesión:', error);
      // Puedes mostrar un mensaje de error aquí
    },
  });

  const login = (email: string, password: string) => {
    // @ts-ignore
    mutation.mutate({ email, password });
  };

  const logout = () => {
    localStorage.removeItem('authToken');
    setToken(null);
    // Redirigir al login
    window.location.href = '/login';
  };

  return (
    // @ts-ignore
    <AuthContext.Provider
      value={{ isAuthenticated, login, logout, token, role, userId }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
