import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const PrivateRoute = () => {
  const { isAuthenticated, token } = useAuth(); // Obtener el estado de autenticación desde el contexto
  if (!isAuthenticated || !token) {
    // Si no está autenticado o no hay token, redirigir al login
    return <Navigate to="/login" />;
  }

  // Si está autenticado, renderizar el componente hijo (Outlet)
  return <Outlet />;
};

export default PrivateRoute;
