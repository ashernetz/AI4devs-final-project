import { Routes, Route, Navigate, Outlet } from 'react-router-dom';
import Login from '../auth/application/login';
import Dashboard from '../dashboard/application/dashboard';
import PrivateRoute from './PrivateRoute';
import { useAuth } from '../context/AuthContext';
import SuperAdminPage from '../superadmin/application/SuperAdminPage';
import RestaurantForm from '../restaurants/application/RestaurantForm';
import RestaurantList from '../restaurants/application/RestaurantList';
import RestaurantDetails from '../restaurants/application/RestaurantDetails';
import RestaurantEditForm from '../restaurants/application/RestaurantEditForm';
import AddEmployeeForm from '../employees/application/AddEmployeeForm';
import EmployeesList from '../employees/application/EmployeesList';
import EmployeeDetails from '../employees/application/EmployeeDetails';
import ProductForm from '../products/application/ProductForm';
import ProductTable from '../products/application/ProductsTable';
import ProductDetails from '../products/application/ProductDetails';
import CategoryForm from '../categories/application/CategoryForm';
import CategoryTable from '../categories/application/CategoriesTable';
import CategoryDetails from '../categories/application/CategoryDetails';
import OrderWizard from '../orders/application/OrderWizard';
import OrderTable from '../orders/application/OrdersTable';
import OrderDetails from '../orders/application/OrderDetails';
const SuperAdminRoute = ({ children }: any) => {
  const { role, token } = useAuth();
  console.log('the role', role);
  if (role !== 'superadmin') {
    return <Navigate to="/dashboard" />; // Redirige si no es superadmin
  }
  return children;
};

const AdminOrAboveRoute = ({ children, redirectTo = 'login' }: any) => {
  const { role } = useAuth();
  const hasPermission =
    role === 'superadmin' || role === 'owner' || role === 'admin';
  if (!hasPermission) {
    localStorage.removeItem('authToken');
    return <Navigate to={`/${redirectTo}`} />;
  }
  return children;
};

const AppRoutes = () => (
  <Routes>
    <Route path="/login" element={<Login />} />
    <Route element={<PrivateRoute />}>
      <Route path="/dashboard" element={<Dashboard />} />
      {/* User Routes */}
      <Route
        path="superadmin"
        element={
          <SuperAdminRoute>
            <SuperAdminPage />
          </SuperAdminRoute>
        }
      />

      <Route
        path="/employees"
        element={
          <AdminOrAboveRoute>
            <EmployeesList />
          </AdminOrAboveRoute>
        }
      />

      <Route
        path="/employees/:id"
        element={
          <AdminOrAboveRoute>
            <EmployeeDetails />
          </AdminOrAboveRoute>
        }
      />

      <Route
        path="/user/add"
        element={
          <AdminOrAboveRoute>
            <AddEmployeeForm />
          </AdminOrAboveRoute>
        }
      />
      {/* Product routes */}
      <Route
        path="/products/new"
        element={
          <AdminOrAboveRoute>
            <ProductForm />
          </AdminOrAboveRoute>
        }
      />

      <Route
        path="/products"
        element={
          <AdminOrAboveRoute>
            <ProductTable />
          </AdminOrAboveRoute>
        }
      />

      <Route
        path="/products/:id"
        element={
          <AdminOrAboveRoute>
            <ProductDetails />
          </AdminOrAboveRoute>
        }
      />
      {/* Order routes */}
      <Route
        path="/orders/new"
        element={
          <AdminOrAboveRoute>
            <OrderWizard />
          </AdminOrAboveRoute>
        }
      />
      <Route
        path="/orders"
        element={
          <AdminOrAboveRoute>
            <OrderTable />
          </AdminOrAboveRoute>
        }
      />
      <Route
        path="/orders/:id"
        element={
          <AdminOrAboveRoute>
            <OrderDetails />
          </AdminOrAboveRoute>
        }
      />
      {/* category routes */}
      <Route
        path="categories/add"
        element={
          <SuperAdminRoute>
            <CategoryForm />
          </SuperAdminRoute>
        }
      />

      <Route
        path="/categories"
        element={
          <SuperAdminRoute>
            <CategoryTable />
          </SuperAdminRoute>
        }
      />

      <Route
        path="/categories/:id"
        element={
          <SuperAdminRoute>
            <CategoryDetails />
          </SuperAdminRoute>
        }
      />

      {/*Rest aurant routes*/}
      <Route
        path="/restaurants/create"
        element={
          <SuperAdminRoute>
            <RestaurantForm />
          </SuperAdminRoute>
        }
      />
      <Route
        path="/restaurants/edit/:id"
        element={
          <SuperAdminRoute>
            <RestaurantEditForm />
          </SuperAdminRoute>
        }
      />
      <Route
        path="/restaurants"
        element={
          <SuperAdminRoute>
            <RestaurantList />
          </SuperAdminRoute>
        }
      />
      <Route
        path="/restaurants/:id"
        element={
          <SuperAdminRoute>
            <RestaurantDetails />
          </SuperAdminRoute>
        }
      />
    </Route>
  </Routes>
);

export default AppRoutes;
