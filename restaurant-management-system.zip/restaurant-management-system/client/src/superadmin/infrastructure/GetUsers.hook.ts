import { useQuery } from '@tanstack/react-query';
import axios from 'axios';

const fetchSuperAdmins = async () => {
  const response = await axios.get(
    'http://localhost:5000/api/users/superadmin',
  );
  return response.data;
};

const useGetSuperAdmins = () => {
  // @ts-ignore
  const { isLoading, data, error } = useQuery(['superAdmin'], fetchSuperAdmins);

  return { isLoading, data, error };
};

export default useGetSuperAdmins;
