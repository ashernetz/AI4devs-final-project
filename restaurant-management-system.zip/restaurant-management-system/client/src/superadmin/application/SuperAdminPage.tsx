import React from 'react';
import SuperAdminForm from './SuperAdminForm';
import SuperAdminList from './SuperAdminList';

const SuperAdminPage = () => {
  return (
    <div>
      <SuperAdminForm />
      <SuperAdminList />
    </div>
  );
};

export default SuperAdminPage;
