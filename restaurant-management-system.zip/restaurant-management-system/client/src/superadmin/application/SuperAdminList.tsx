import React, { useState, useEffect } from 'react';
import {
  Button,
  List,
  ListItem,
  ListItemText,
  Typography,
} from '@mui/material';
import axios from 'axios';

const SuperAdminList = () => {
  const [superAdmins, setSuperAdmins] = useState([]);

  useEffect(() => {
    const fetchSuperAdmins = async () => {
      const response = await axios.get(
        'http://localhost:5000/api/users/superadmin',
      );
      setSuperAdmins(response.data);
    };
    fetchSuperAdmins();
  }, []);

  const handleDelete = async (id: string) => {
    try {
      await axios.delete(`http://localhost:5000/api/superadmin/${id}`);
      setSuperAdmins(superAdmins.filter((admin: any) => admin._id !== id));
    } catch (error) {
      console.error('Failed to delete SuperAdmin', error);
    }
  };

  return (
    <div>
      <Typography variant="h4">SuperAdmin List</Typography>
      <List>
        {superAdmins.map((admin:any) => (
          <ListItem key={admin?._id}>
            <ListItemText primary={admin.name} secondary={admin.email} />
            <Button
              variant="contained"
              color="secondary"
              onClick={() => handleDelete(admin?._id)}
            >
              Delete
            </Button>
          </ListItem>
        ))}
      </List>
    </div>
  );
};

export default SuperAdminList;
