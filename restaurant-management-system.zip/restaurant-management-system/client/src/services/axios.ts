import axios from 'axios';

const apiClient = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor para incluir el token en todas las solicitudes
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken'); // Verificar si el token está en localStorage
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    console.log('the token', token);
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`; // Incluir el token en el header Authorization
    }
    if (user && user.id && user.role) {
      config.headers['user'] = JSON.stringify({
        id: user.id,
        role: user.role,
      });
    }
    console.log('config.headers', config.headers);
    return config;
  },
  (error) => {
    return Promise.reject(error);
  },
);

export default apiClient;
