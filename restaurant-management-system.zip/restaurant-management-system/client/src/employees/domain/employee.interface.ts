export interface Employee {
  _id: string | null;
  name: string;
  email: string;
  role: string;
  restaurantId: string;
  createdAt: Date;
  updatedAt: Date;
}
