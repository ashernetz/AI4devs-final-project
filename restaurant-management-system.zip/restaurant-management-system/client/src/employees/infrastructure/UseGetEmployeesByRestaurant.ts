import { useQuery } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { Employee } from '../domain/employee.interface';

const useGetEmployeesByRestaurant = (restaurantId: string | null) => {
  const { isLoading, data, error, refetch, isFetching } = useQuery({
    queryKey: ['employees', restaurantId],
    queryFn: () => fetchEmployeesByRestaurant(restaurantId),
    enabled: !!restaurantId,
  });
  const fetchEmployeesByRestaurant = async (
    id: string | null,
  ): Promise<Employee[]> => {
    const response = await apiClient.get(`/users/restaurant/${restaurantId}`);
    return response.data;
  };

  return {
    isLoading,
    data,
    error,
  };
};

export default useGetEmployeesByRestaurant;
