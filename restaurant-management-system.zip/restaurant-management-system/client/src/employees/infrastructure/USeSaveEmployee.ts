import { useMutation } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { useState } from 'react';

const useSaveEmployee = () => {
  const [isLoading, setIsLoading] = useState(false);
  const mutation = useMutation({
    mutationFn: (params: any) => apiClient.post('/users/register', params),

    onSettled: () => {
      setIsLoading(false);
    },
  });
  const postEmployee = async (employeeData: any) => {
    setIsLoading(true);
    return mutation.mutateAsync(employeeData);
  };

  return {
    isLoading,
    mutate: postEmployee,
    isError: mutation.isError,
  };
};

export default useSaveEmployee;
