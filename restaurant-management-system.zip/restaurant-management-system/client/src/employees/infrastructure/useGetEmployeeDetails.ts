import { useQuery, useMutation } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { Employee } from '../domain/employee.interface';
import { useState } from 'react';

interface IGetEmployeesByRestaurant {
  restaurantId: string | null;
  role: string | null;
  employeeId: string | null;
}

const useGetEmployeesByRestaurant = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [userData, setUserData] = useState<any>(null);
  const mutation = useMutation({
    mutationFn: (params: any) => apiClient.post('/users/details', params),
    onSettled: (response) => {
      setIsLoading(false);
      setUserData(response?.data);
    },
  });

  const fetchEmployeesByRestaurant = async ({
    restaurantId,
    role,
    employeeId,
  }: IGetEmployeesByRestaurant) => {
    setIsLoading(true);
    return mutation.mutateAsync({ restaurantId, role, employeeId });
  };

  return {
    isLoading,
    userData,
    mutate: fetchEmployeesByRestaurant,
    isError: mutation.isError,
  };
};

export default useGetEmployeesByRestaurant;
