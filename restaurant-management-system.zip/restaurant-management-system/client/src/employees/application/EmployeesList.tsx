import { useAuth } from '../../context/AuthContext';
import { useRestaurant } from '../../context/RestaurantContext';
import { useNavigate } from 'react-router-dom';
import useGetEmployeesByRestaurant from '../infrastructure/UseGetEmployeesByRestaurant';
import Spinner from '../../components/Spinner';
import { Typography } from '@mui/material';
import React, { useEffect } from 'react';
import EmployeeTable from './employeesTable';

const EmployeesList = () => {
  const { logout } = useAuth(); // Acceder a la función de logout desde el contexto
  const { selectedRestaurantId } = useRestaurant();
  const navigate = useNavigate();
  const {
    data: employees,
    isLoading,
    error,
  } = useGetEmployeesByRestaurant(selectedRestaurantId); // Asume que tienes un hook useEmployees para obtener los empleados

  useEffect(() => {
    if (!selectedRestaurantId) {
      logout();
    }
  }, []);

  if (isLoading) return <Spinner loading={isLoading} />;
  if (error) return <Typography variant="h6">{error.message}</Typography>;
  if (!employees)
    return <Typography variant="h6">No employees found</Typography>;
  return (
    <div>
      <Typography variant="h4">Employees List</Typography>
      <EmployeeTable employees={employees} />
    </div>
  );
};
export default EmployeesList;
