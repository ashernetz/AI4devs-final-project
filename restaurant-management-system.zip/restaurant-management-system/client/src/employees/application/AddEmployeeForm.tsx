import React, { useEffect, useState } from 'react';
import {
  Button,
  TextField,
  Container,
  Box,
  Typography,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
} from '@mui/material';
import toast from 'react-hot-toast';
import { useParams } from 'react-router-dom';
import useSaveEmployee from '../infrastructure/USeSaveEmployee';
import { useAuth } from '../../context/AuthContext';
import { useRestaurant } from '../../context/RestaurantContext';
import Spinner from '../../components/Spinner';

const AddEmployeeForm = () => {
  const { logout } = useAuth(); // Acceder a la función de logout desde el contexto
  const { selectedRestaurantId } = useRestaurant();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');

  const { mutate, isLoading, isError } = useSaveEmployee();
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Crear el nuevo empleado (usuario)
      await mutate({
        name,
        email,
        password,
        role,
        restaurantId: selectedRestaurantId,
      });
      toast.success('empleado agregado correctamente');
      cleanForm();
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  const cleanForm = () => {
    setName('');
    setEmail('');
    setPassword('');
    setRole('');
  };

  useEffect(() => {
    console.log(selectedRestaurantId);
    if (!selectedRestaurantId) {
      logout();
    }
  }, [selectedRestaurantId]);

  if (isLoading) return <Spinner loading={isLoading} />;

  return (
    <Container component="main" maxWidth="sm">
      <Box sx={{ mt: 8 }}>
        <Typography component="h1" variant="h5">
          Add Employee to Restaurant
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            margin="normal"
            required
            fullWidth
            label="Employee Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            label="Employee Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <FormControl fullWidth margin="normal" required>
            <InputLabel>Role</InputLabel>
            <Select
              value={role}
              onChange={(e) => setRole(e.target.value as string)}
              label="Role"
            >
              <MenuItem value="owner">Owner</MenuItem>
              <MenuItem value="admin">Admin</MenuItem>
              <MenuItem value="manager">Manager</MenuItem>
              <MenuItem value="staff">Staff</MenuItem>
            </Select>
          </FormControl>
          <Button type="submit" fullWidth variant="contained" sx={{ mt: 3 }}>
            {isLoading ? 'Adding...' : 'Add Employee'}
          </Button>
        </form>
      </Box>
    </Container>
  );
};

export default AddEmployeeForm;
