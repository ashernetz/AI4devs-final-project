import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Card,
  CardContent,
  Typography,
  Avatar,
  Button,
  CardActions,
  CircularProgress,
  Box,
} from '@mui/material';
import Grid2 from '@mui/material/Grid2'; // Importa Grid2 desde MUI correctamente
import { useAuth } from '../../context/AuthContext';
import { useRestaurant } from '../../context/RestaurantContext';
import useGetEmployeesByRestaurant from '../infrastructure/useGetEmployeeDetails';
import PersonIcon from '@mui/icons-material/Person';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

const EmployeeDetails = () => {
  const { id: employeeId } = useParams<{ id: string }>();
  const { role } = useAuth();
  const { selectedRestaurantId } = useRestaurant();
  const navigate = useNavigate();

  const {
    mutate: fetchDetails,
    isError,
    isLoading,
    userData,
  } = useGetEmployeesByRestaurant();
  console.log('userData', userData);
  useEffect(() => {
    if (employeeId && role && selectedRestaurantId) {
      fetchDetails({
        restaurantId: selectedRestaurantId,
        role,
        employeeId,
      });
    }
  }, [employeeId, role, selectedRestaurantId]);

  if (isLoading) {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: '50vh',
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  if (isError || !userData) {
    return (
      <Typography color="error">Error loading employee details.</Typography>
    );
  }

  return (
    <Card sx={{ maxWidth: 600, margin: 'auto', mt: 5, p: 2 }}>
      <Grid2 container spacing={2} justifyContent="center" alignItems="center">
        <Grid2 size={12}>
          <Avatar sx={{ width: 64, height: 64 }}>
            <PersonIcon fontSize="large" />
          </Avatar>
        </Grid2>
        <Grid2 size={12}>
          <Typography variant="h5" component="div" gutterBottom>
            {userData.name}
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Role: {userData.role}
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Email: {userData.email}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Status: {userData.status}
          </Typography>
        </Grid2>
      </Grid2>

      <CardContent>
        <Typography variant="body1" color="text.primary">
          Employee details of {userData.name} in the role of {userData.role} at
          the restaurant.
        </Typography>
      </CardContent>

      <CardActions>
        <Button
          variant="outlined"
          color="primary"
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate(-1)} // Volver a la página anterior
        >
          Back
        </Button>
        {/* Puedes añadir otros botones aquí para acciones adicionales */}
      </CardActions>
    </Card>
  );
};

export default EmployeeDetails;
