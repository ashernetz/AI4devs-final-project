import { useNavigate } from 'react-router-dom';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Button,
} from '@mui/material';
import { Employee } from '../domain/employee.interface';
import { useState } from 'react'; // Asume que tienes un interface IUser para empleados

interface EmployeeTableProps {
  employees: Employee[];
}

const EmployeeTable = ({ employees }: EmployeeTableProps) => {
  const [setSelectedEmployeeId, selectedEmployeeId] = useState(null);
  const navigate = useNavigate();
  const handleViewDetails = (id: string | null) => {
    if (!id) return;
    navigate(`/employees/${id}`);
  };

  // Función para redirigir a la página de edición del empleado
  const handleEditEmployee = (id: string | null, e: React.MouseEvent) => {
    e.stopPropagation(); // Evitar que el clic en la fila se dispare
    if (!id) return;
    navigate(`/employees/edit/${id}`);
  };

  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="employee table">
        <TableHead>
          <TableRow>
            <TableCell>
              <Typography variant="h6">Employee Name</Typography>
            </TableCell>
            <TableCell align="right">
              <Typography variant="h6">Email</Typography>
            </TableCell>
            <TableCell align="right">
              <Typography variant="h6">Role</Typography>
            </TableCell>
            <TableCell align="right">
              <Typography variant="h6">Actions</Typography>
            </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {employees.map((employee: Employee) => (
            <TableRow
              key={employee._id}
              sx={{
                cursor: 'pointer',
                '&:hover': { backgroundColor: '#f5f5f5' },
              }}
            >
              <TableCell component="th" scope="row">
                {employee.name}
              </TableCell>
              <TableCell align="right">{employee.email}</TableCell>
              <TableCell align="right">{employee.role}</TableCell>
              <TableCell align="right">
                {/* Botón para ver detalles del empleado */}
                <Button
                  variant="contained"
                  color="primary"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleViewDetails(employee._id);
                  }}
                  sx={{ mr: 1 }}
                >
                  View Details
                </Button>

                {/* Botón para editar empleado */}
                <Button
                  variant="outlined"
                  color="secondary"
                  onClick={(e) => handleEditEmployee(employee._id, e)}
                >
                  Edit Employee
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default EmployeeTable;
