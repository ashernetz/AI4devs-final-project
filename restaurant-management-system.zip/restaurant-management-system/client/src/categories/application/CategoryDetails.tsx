import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Card,
  CardContent,
  Typography,
  Button,
  CardActions,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import useGetCategoryDetails from '../infrastructure/useGetCategoryDetails';
import Spinner from '../../components/Spinner';

interface ICategory {
  _id: string;
  name: string;
  description?: string;
}

const CategoryDetails: React.FC = () => {
  const { id: categoryId } = useParams<{ id: string }>(); // Obtener el ID de la categoría desde la URL
  const navigate = useNavigate();
  const {
    isLoading,
    data: categoryDetails,
    error,
  } = useGetCategoryDetails(categoryId);

  if (isLoading) {
    return <Spinner isLoading={isLoading} />;
  }

  if (!categoryDetails || error) {
    return <Typography color="error">Category not found.</Typography>;
  }

  return (
    <Card sx={{ maxWidth: 600, margin: 'auto', mt: 5, p: 2 }}>
      <CardContent>
        <Typography variant="h5" component="div" gutterBottom>
          {categoryDetails.name}
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Description:{' '}
          {categoryDetails.description || 'No description available'}
        </Typography>
      </CardContent>

      <CardActions>
        <Button
          variant="outlined"
          color="primary"
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate(-1)} // Volver a la página anterior
        >
          Back
        </Button>
      </CardActions>
    </Card>
  );
};

export default CategoryDetails;
