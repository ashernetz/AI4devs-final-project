import React, { useState } from 'react';
import { TextField, Button, Container, Box, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import useSaveCategory from '../infrastructure/useSaveCategory';
import Spinner from '../../components/Spinner'; // Para notificaciones

const CategoryForm = () => {
  /**
   * @todo
   * - Agregar un campo para el restaurante.
   * - Hacer la diferenciación cuando es para un restaurante o en general.
   * */
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const navigate = useNavigate();

  const { mutate: createCategory, isLoading, isError } = useSaveCategory();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      createCategory({ name, description });
      toast.success('Category created successfully');
      navigate('/categories');
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  if (isLoading) {
    return <Spinner isLoading={isLoading} />;
  }

  return (
    <Container component="main" maxWidth="sm">
      <Box sx={{ mt: 8 }}>
        <Typography component="h1" variant="h5">
          Add New Category
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            margin="normal"
            required
            fullWidth
            label="Category Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoFocus
          />
          <TextField
            margin="normal"
            fullWidth
            label="Description (Optional)"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            multiline
            rows={4}
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            disabled={isLoading}
            sx={{ mt: 3 }}
          >
            {isLoading ? 'Saving...' : 'Create Category'}
          </Button>
        </form>
      </Box>
    </Container>
  );
};

export default CategoryForm;
