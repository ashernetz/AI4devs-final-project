import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Button,
  Box,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Spinner from '../../components/Spinner';
import useCategoriesApi from '../infrastructure/useGetCategories';

interface ICategory {
  _id: string;
  name: string;
  description?: string;
}

const CategoryTable: React.FC = () => {
  const navigate = useNavigate();
  const { isLoading, data: categories, error } = useCategoriesApi();

  if (isLoading) {
    return <Spinner loading={isLoading} />;
  }

  if (error || !categories) {
    return <Typography variant="h6">Error loading categories</Typography>;
  }

  return (
    <Box sx={{ position: 'relative', paddingBottom: '80px' }}>
      <TableContainer component={Paper} sx={{ mt: 4 }}>
        <Table sx={{ minWidth: 650 }} aria-label="category table">
          <TableHead>
            <TableRow>
              <TableCell>
                <Typography variant="h6">Category Name</Typography>
              </TableCell>
              <TableCell align="left">
                <Typography variant="h6">Description</Typography>
              </TableCell>
              <TableCell align="center">
                <Typography variant="h6">Actions</Typography>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {categories.map((category) => (
              <TableRow
                key={category._id}
                sx={{
                  cursor: 'pointer',
                  '&:hover': { backgroundColor: '#f5f5f5' },
                }}
              >
                <TableCell component="th" scope="row">
                  {category.name}
                </TableCell>
                <TableCell align="left">
                  {category.description || 'N/A'}
                </TableCell>
                <TableCell align="center">
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => navigate(`/categories/${category._id}`)}
                    sx={{ mr: 1 }}
                  >
                    View Details
                  </Button>
                  <Button
                    variant="outlined"
                    color="secondary"
                    onClick={() => navigate(`/categories/edit/${category._id}`)}
                  >
                    Edit
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Botón para agregar nueva categoría */}
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', marginTop: 3 }}>
        <Button
          variant="contained"
          color="primary"
          onClick={() => navigate('/categories/add')}
        >
          Add Category
        </Button>
      </Box>
    </Box>
  );
};

export default CategoryTable;
