import { useMutation } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { useState } from 'react';

const useSaveCategory = () => {
  const [isLoading, setIsLoading] = useState(false);
  const mutation = useMutation({
    mutationFn: (params: any) => apiClient.post('/categories', params),

    onSettled: () => {
      setIsLoading(false);
    },
  });
  const saveCategory = async (categoryData: any) => {
    setIsLoading(true);
    return mutation.mutateAsync(categoryData);
  };

  return {
    isLoading,
    mutate: saveCategory,
    isError: mutation.isError,
  };
};
export default useSaveCategory;
