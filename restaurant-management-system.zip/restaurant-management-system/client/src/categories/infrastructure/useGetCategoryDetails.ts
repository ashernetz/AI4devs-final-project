import { useQuery } from '@tanstack/react-query';
import apiClient from '../../services/axios';

const useGetCategoryDetails = (id: string | undefined) => {
  const { isLoading, data, error } = useQuery({
    queryKey: ['category', id],
    queryFn: () => fetchCategoryById(id),
    enabled: !!id,
  });

  const fetchCategoryById = async (id: string | undefined) => {
    if (!id) throw new Error('Category ID is required');
    const response = await apiClient.get(`/categories/${id}`);
    return response.data;
  };

  return {
    isLoading,
    data,
    error,
  };
};

export default useGetCategoryDetails;
