import { useQuery } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { Category } from '../domain/categories.interface';

const useCategoriesApi = () => {
  const { isLoading, data, error, refetch, isFetching } = useQuery({
    queryKey: ['categories'],
    queryFn: fetchCategories,
  });

  return {
    isLoading,
    data,
    error,
    refetch,
    isFetching,
  };
};

const fetchCategories = async (): Promise<Category[]> => {
  const response = await apiClient.get('/categories');
  return response.data;
};

export default useCategoriesApi;
