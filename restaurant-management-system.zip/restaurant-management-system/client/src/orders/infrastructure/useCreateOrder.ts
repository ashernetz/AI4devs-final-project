import { useMutation } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { useState } from 'react';

const useCreateOrder = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [orderInfo, setOrderInfo] = useState<any>(null);
  const mutation = useMutation({
    mutationFn: (params: any) => apiClient.post('/orders', params),

    onSettled: (response) => {
      setIsLoading(false);
      setOrderInfo(response?.data);
    },
  });

  const createOrder = async (orderData: any) => {
    setIsLoading(true);
    return mutation.mutateAsync(orderData);
  };

  return {
    isLoading,
    mutate: createOrder,
    isError: mutation.isError,
    orderInfo,
  };
};

export default useCreateOrder;
