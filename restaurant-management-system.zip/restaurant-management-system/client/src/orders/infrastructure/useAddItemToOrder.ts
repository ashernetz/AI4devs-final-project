import { useMutation } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { useState } from 'react';

const useAddItemToOrder = () => {
  const [isLoading, setIsLoading] = useState(false);
  const mutation = useMutation({
    mutationFn: (params: any) => apiClient.post('/order-item', params),
    onSettled: () => {
      setIsLoading(false);
    },
  });

  const addItemToOrder = async (orderItemData: any) => {
    setIsLoading(true);
    return mutation.mutateAsync(orderItemData);
  };

  return {
    isLoading,
    mutate: addItemToOrder,
    isError: mutation.isError,
  };
};
export default useAddItemToOrder;
