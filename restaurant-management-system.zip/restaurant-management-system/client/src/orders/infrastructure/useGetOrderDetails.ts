import { useQuery } from '@tanstack/react-query';
import apiClient from '../../services/axios';

const useGetOrderDetails = (orderId: string | undefined) => {
  const { isLoading, data, error, refetch, isFetching } = useQuery({
    queryKey: ['orderDetails', orderId],
    queryFn: () => fetchOrderDetails(orderId),
    enabled: !!orderId,
  });

  return {
    isLoading,
    data,
    error,
    refetch,
    isFetching,
  };
};

const fetchOrderDetails = async (orderId: string | undefined): Promise<any> => {
  if (!orderId) throw new Error('Order ID is required');
  const response = await apiClient.get(`/orders/details/${orderId}`);
  return response.data;
};

export default useGetOrderDetails;
