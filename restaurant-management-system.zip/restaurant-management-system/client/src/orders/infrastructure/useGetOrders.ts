import { useQuery } from '@tanstack/react-query';
import apiClient from '../../services/axios';

const useCategoriesApi = (restaurantId: string | null) => {
  const { isLoading, data, error, refetch, isFetching } = useQuery({
    queryKey: ['categories', restaurantId],
    queryFn: () => fetchCategories(restaurantId),
    enabled: !!restaurantId,
  });

  return {
    isLoading,
    data,
    error,
    refetch,
    isFetching,
  };
};

const fetchCategories = async (restaurantId: string | null): Promise<any> => {
  if (!restaurantId) throw new Error('Restaurant ID is required');
  const response = await apiClient.get(`/orders/restaurant/${restaurantId}`);
  return response.data;
};

export default useCategoriesApi;
