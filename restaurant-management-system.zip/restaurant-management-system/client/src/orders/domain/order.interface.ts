export interface IOrderItemForm {
  productId: string;
  description: string;
  quantity: number;
}
