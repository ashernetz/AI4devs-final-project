import { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import {
  Box,
  Button,
  Card,
  CardContent,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  TextField,
  Typography,
} from '@mui/material';
import Grid2 from '@mui/material/Grid2';
import Spinner from '../../components/Spinner';
import { IProduct } from '../../products/domain/product.interface';
import { IOrderItemForm } from '../domain/order.interface';
import useCategoriesApi from '../../categories/infrastructure/useGetCategories';
import useGetProducts from '../../products/infrastructure/useGetProducts';
import { useRestaurant } from '../../context/RestaurantContext';
import useAddItemToOrder from '../infrastructure/useAddItemToOrder';
import toast from 'react-hot-toast'; // Importa Grid2 desde MUI correctamente

interface AddOrderItemsProps {
  orderId: string;
}

const AddOrderItems = ({ orderId }: AddOrderItemsProps) => {
  /* Hooks de Estado */
  const [filteredProducts, setFilteredProducts] = useState<IProduct[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<IProduct | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [orderItemForm, setOrderItemForm] = useState<IOrderItemForm>({
    productId: '',
    description: '',
    quantity: 1,
  });
  const [dialogOpen, setDialogOpen] = useState(false);

  /* TanStack Hooks */
  const {
    isLoading: isLoadingCategories,
    error: categoriesError,
    data: categories,
  } = useCategoriesApi();
  const {
    isLoading: isLoadingProducts,
    isError: isErrorProducts,
    mutate: getProducts,
    productsData: products,
  } = useGetProducts();
  const {
    isLoading: isLoadingAddItem,
    mutate: addItemToOrder,
    isError: isErrorAddingItem,
  } = useAddItemToOrder();

  const { selectedRestaurantId } = useRestaurant();
  const isLoading =
    isLoadingCategories || isLoadingProducts || isLoadingAddItem;
  useEffect(() => {
    if (selectedRestaurantId) {
      getProducts(selectedRestaurantId);
    }
  }, [selectedRestaurantId]);

  useEffect(() => {
    if (searchTerm) {
      const filtered = products.filter((product: IProduct) =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase()),
      );
      setFilteredProducts(filtered);
    } else {
      setFilteredProducts(products);
    }
  }, [searchTerm, products]);

  const handleSelectProduct = (product: IProduct) => {
    setSelectedProduct(product);
    setOrderItemForm({ productId: product._id, description: '', quantity: 1 });
    setDialogOpen(true);
  };

  const handleAddToOrder = async () => {
    // Aquí puedes agregar la lógica para agregar el item a la orden.
    const orderItemData = {
      selectedRestaurantId,
      orderId,
      quantity: orderItemForm.quantity,
      productId: orderItemForm.productId,
      description: orderItemForm.description,
      price: selectedProduct!.price * orderItemForm.quantity,
    };
    try {
      await addItemToOrder(orderItemData);
      setDialogOpen(false);
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  if (isLoading) {
    return <Spinner loading={isLoading} />;
  }

  if (isLoading) return <Spinner loading={isLoadingCategories} />;
  if (!categories || !products)
    return <div>Error: there are elements that were not loaded</div>;

  return (
    <Box sx={{ mt: 4 }}>
      {/* Elemento 1: Input de Búsqueda */}
      <TextField
        fullWidth
        label="Search Products"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        sx={{ mb: 3 }}
      />
      {/* Elemento 2: Grid de Productos por Categoría */}
      {categories.map((category) => (
        <Box key={category._id} sx={{ mb: 4 }}>
          <Typography variant="h6">{category.name}</Typography>
          <Grid2 container spacing={2}>
            {filteredProducts
              .filter((product) => product.categoryId === category._id)
              .map((product) => (
                <Grid2 size={12} key={product._id}>
                  <Card
                    onClick={() => handleSelectProduct(product)}
                    sx={{ cursor: 'pointer' }}
                  >
                    <CardContent>
                      <Typography variant="h6">{product.name}</Typography>
                      <Typography variant="body2">
                        Price: ${product.price}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid2>
              ))}
          </Grid2>
        </Box>
      ))}
      {/* Formulario para agregar producto a la orden */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)}>
        <DialogTitle>Add Product to Order</DialogTitle>
        <DialogContent>
          <Typography variant="h6">{selectedProduct?.name}</Typography>
          <TextField
            fullWidth
            label="Description"
            value={orderItemForm.description}
            onChange={(e) =>
              setOrderItemForm({
                ...orderItemForm,
                description: e.target.value,
              })
            }
            sx={{ mt: 2 }}
          />
          <TextField
            fullWidth
            label="Quantity"
            type="number"
            value={orderItemForm.quantity}
            onChange={(e) =>
              setOrderItemForm({
                ...orderItemForm,
                quantity: Number(e.target.value),
              })
            }
            sx={{ mt: 2 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)} color="secondary">
            Cancel
          </Button>
          <Button onClick={handleAddToOrder} color="primary">
            Add to Order
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

AddOrderItems.propTypes = {
  orderId: PropTypes.string.isRequired,
};

export default AddOrderItems;
