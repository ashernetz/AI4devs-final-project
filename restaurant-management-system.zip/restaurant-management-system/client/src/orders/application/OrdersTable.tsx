import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Typography,
  Button,
  Card,
  CardContent,
  CardActions,
  Box,
} from '@mui/material';
import Grid2 from '@mui/material/Grid2';
import Spinner from '../../components/Spinner';
import useCategoriesApi from '../infrastructure/useGetOrders';
import { useRestaurant } from '../../context/RestaurantContext';

const OrderTable = () => {
  const { selectedRestaurantId } = useRestaurant();
  const navigate = useNavigate();
  const {
    isLoading,
    error,
    data: orders,
  } = useCategoriesApi(selectedRestaurantId);

  if (isLoading) {
    return <Spinner loading={isLoading} />;
  }

  if (error || !orders) {
    return <Typography variant="h6">No orders found</Typography>;
  }

  return (
    <Box sx={{ position: 'relative', paddingBottom: '80px' }}>
      <Grid2 container spacing={3}>
        {orders.map((order: any) => (
          <Grid2 size={4} key={order._id}>
            <Card
              sx={{
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                '&:hover': { boxShadow: 6 },
              }}
            >
              <CardContent sx={{ flexGrow: 1 }}>
                <Typography variant="h6" gutterBottom>
                  Order Status: {order.status}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Date: {new Date(order.createdAt).toLocaleDateString()}
                </Typography>
                <Typography variant="body2">
                  Table Number: {order.tableNumber || 'N/A'}
                </Typography>
                <Typography variant="body2">
                  Total: ${order.totalAmount}
                </Typography>
                <Typography variant="body2">
                  Products: {order.productCount}
                </Typography>
              </CardContent>
              <CardActions sx={{ justifyContent: 'space-between' }}>
                <Button
                  size="small"
                  color="primary"
                  onClick={() => navigate(`/orders/${order._id}`)}
                >
                  View
                </Button>
                <Button
                  size="small"
                  color="secondary"
                  onClick={() => navigate(`/orders/edit/${order._id}`)}
                >
                  Edit
                </Button>
              </CardActions>
            </Card>
          </Grid2>
        ))}
      </Grid2>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', marginTop: 3 }}>
        <Button
          variant="contained"
          color="primary"
          onClick={() => navigate('/orders/new')}
        >
          Add order
        </Button>
      </Box>
    </Box>
  );
};

export default OrderTable;
