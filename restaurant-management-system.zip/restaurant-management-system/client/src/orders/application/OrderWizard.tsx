import {
  TextField,
  Button,
  Container,
  Box,
  Typography,
  Stepper,
  Step,
  StepLabel,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import useCreateOrder from '../infrastructure/useCreateOrder';
import toast from 'react-hot-toast';
import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useRestaurant } from '../../context/RestaurantContext';
import AddOrderItems from './AddOrderItems';

const OrderWizard = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [tableNumber, setTableNumber] = useState('');
  const { mutate: createOrder, isLoading, orderInfo } = useCreateOrder(); // Hook para crear la orden
  const { userId } = useAuth(); // Acceder a la función de logout desde el contexto
  const { selectedRestaurantId } = useRestaurant();

  const steps = ['Create Order', 'Add Items', 'Review & Confirm'];
  const navigate = useNavigate();
  console.log('orderInfo', orderInfo);
  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleCreateOrder = async () => {
    try {
      console.log(tableNumber, userId, selectedRestaurantId);
      await createOrder({
        tableNumber,
        userId,
        restaurantId: selectedRestaurantId,
      });
      handleNext();
      console.log('orderInfo', orderInfo);
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  return (
    <Container component="main" maxWidth="sm">
      <Box sx={{ mt: 8 }}>
        <Typography component="h1" variant="h5">
          Create Order
        </Typography>
        <Stepper activeStep={activeStep} alternativeLabel>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        {activeStep === 0 && (
          <>
            <TextField
              margin="normal"
              fullWidth
              label="Table Number (Optional)"
              value={tableNumber}
              onChange={(e) => setTableNumber(e.target.value)}
            />
            <Button
              fullWidth
              variant="contained"
              color="primary"
              onClick={handleCreateOrder}
              disabled={isLoading}
            >
              {isLoading ? 'Creating...' : 'Create Order'}
            </Button>
          </>
        )}
        {activeStep === 1 && (
          <>
            <Typography>Now you can add items to the order.</Typography>
            <AddOrderItems orderId={orderInfo?._id} />
            <Button
              fullWidth
              variant="contained"
              color="primary"
              onClick={() => handleNext()}
            >
              Next
            </Button>
          </>
        )}
        {activeStep === 2 && (
          <>
            <Typography>Review your order and confirm.</Typography>
            <Button
              fullWidth
              variant="contained"
              color="primary"
              onClick={() => navigate('/orders')}
            >
              Confirm Order
            </Button>
          </>
        )}
        {activeStep > 0 && (
          <Button fullWidth variant="text" color="primary" onClick={handleBack}>
            Back
          </Button>
        )}
      </Box>
    </Container>
  );
};

export default OrderWizard;
