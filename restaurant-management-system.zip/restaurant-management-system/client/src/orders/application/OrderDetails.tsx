import React, { useEffect, useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Divider,
  CircularProgress,
  Button,
} from '@mui/material';
import { useNavigate, useParams } from 'react-router-dom';
import useGetOrderDetails from '../infrastructure/useGetOrderDetails';

interface IProduct {
  productId: string;
  productName: string;
  quantity: number;
  price: number;
  description: string;
  total: number;
}

interface IOrder {
  _id: string;
  restaurant: { _id: string; name: string };
  user: { _id: string; name: string; email: string };
  tableNumber: string;
  createdAt: string;
  status: string;
  totalAmount: number;
  products: IProduct[];
}

const OrderDetails: React.FC = () => {
  const navigate = useNavigate();
  const { id: orderId } = useParams<{ id: string }>(); // Obtener el ID de la orden desde la URL
  const { isLoading, error, data: orderDetails } = useGetOrderDetails(orderId);

  if (isLoading) {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh',
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  if (!orderDetails) {
    return (
      <Typography variant="h6" color="error">
        Order not found
      </Typography>
    );
  }

  return (
    <Card sx={{ maxWidth: 800, margin: 'auto', mt: 5, p: 3 }}>
      <CardContent>
        {/* Información General de la Orden */}
        <Typography variant="h4" gutterBottom>
          Order Details
        </Typography>
        <Divider sx={{ mb: 3 }} />

        <Typography variant="body1" gutterBottom>
          <strong>Restaurant:</strong> {orderDetails.restaurant.name}
        </Typography>
        <Typography variant="body1" gutterBottom>
          <strong>Issued by:</strong> {orderDetails.user.name} (
          {orderDetails.user.email})
        </Typography>
        <Typography variant="body1" gutterBottom>
          <strong>Table Number:</strong> {orderDetails.tableNumber || 'N/A'}
        </Typography>
        <Typography variant="body1" gutterBottom>
          <strong>Order Status:</strong> {orderDetails.status.toUpperCase()}
        </Typography>
        <Typography variant="body1" gutterBottom>
          <strong>Date:</strong>{' '}
          {new Date(orderDetails.createdAt).toLocaleDateString()}
        </Typography>

        {/* Listado de Productos */}
        <TableContainer component={Paper} sx={{ mt: 4 }}>
          <Table sx={{ minWidth: 650 }} aria-label="product table">
            <TableHead>
              <TableRow>
                <TableCell>
                  <Typography variant="h6">Product</Typography>
                </TableCell>
                <TableCell align="center">
                  <Typography variant="h6">Quantity</Typography>
                </TableCell>
                <TableCell align="center">
                  <Typography variant="h6">Price</Typography>
                </TableCell>
                <TableCell align="center">
                  <Typography variant="h6">Total</Typography>
                </TableCell>
                <TableCell align="center">
                  <Typography variant="h6">Description</Typography>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {orderDetails.products.map((product: any) => (
                <TableRow key={product.productId}>
                  <TableCell component="th" scope="row">
                    {product.productName}
                  </TableCell>
                  <TableCell align="center">{product.quantity}</TableCell>
                  <TableCell align="center">
                    ${product.price.toFixed(2)}
                  </TableCell>
                  <TableCell align="center">
                    ${product.total.toFixed(2)}
                  </TableCell>
                  <TableCell align="center">
                    {product.description || 'N/A'}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Resumen del Total */}
        <Box sx={{ mt: 4, display: 'flex', justifyContent: 'space-between' }}>
          <Typography variant="h5">Total Amount:</Typography>
          <Typography variant="h5">
            ${orderDetails.totalAmount.toFixed(2)}
          </Typography>
        </Box>

        {/* Botón de Acción */}
        <Button
          variant="contained"
          color="primary"
          fullWidth
          sx={{ mt: 3 }}
          onClick={() => navigate('/orders')}
        >
          Back to Orders
        </Button>
      </CardContent>
    </Card>
  );
};

export default OrderDetails;
