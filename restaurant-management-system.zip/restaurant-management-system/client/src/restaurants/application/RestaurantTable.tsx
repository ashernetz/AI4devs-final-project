import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Button,
  Card,
  CardContent,
  CardActions,
} from '@mui/material';
import { IRestaurant } from '../domain/restaurant.interface';
import { useRestaurant } from '../../context/RestaurantContext';
import Grid2 from '@mui/material/Grid2'; // Importa Grid2 desde MUI correctamente
interface RestaurantTableProps {
  restaurants: IRestaurant[];
}

const RestaurantTable: React.FC<RestaurantTableProps> = ({ restaurants }) => {
  const { storeRestaurantId } = useRestaurant();
  const navigate = useNavigate();

  // Función para redirigir a los detalles del restaurante
  const handleRowClick = (id: string) => {
    navigate(`/restaurants/${id}`);
  };

  const viewEmployees = (id: string) => {
    navigate(`/employees`);
  };

  // Función para redirigir a la página de edición del restaurante
  const handleEditClick = (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Evitar que el clic en la fila se dispare
    navigate(`/restaurants/edit/${id}`);
  };

  // Función para redirigir a la página de agregar empleado
  const handleAddEmployeeClick = (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Evitar que el clic en la fila se dispare
    storeRestaurantId(id);
    navigate(`/user/add`);
  };

  return (
    <Grid2 container spacing={3}>
      {restaurants.map((restaurant) => (
        <Grid2 size={4} key={restaurant._id}>
          <Card
            sx={{
              cursor: 'pointer',
              '&:hover': { boxShadow: 6 },
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
            }}
            onClick={() => handleRowClick(restaurant._id)}
          >
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography variant="h6" gutterBottom>
                {restaurant.name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {restaurant.address}
              </Typography>
              <Typography variant="body2">
                Owner: {restaurant.ownerId?.name}
              </Typography>
              <Typography variant="body2">
                Employees: {restaurant.employeeCount}
              </Typography>
            </CardContent>
            <CardActions
              sx={{ justifyContent: 'space-between', flexWrap: 'wrap' }}
            >
              <Button
                size="small"
                color="primary"
                onClick={(e) => {
                  e.stopPropagation();
                  handleRowClick(restaurant._id);
                }}
              >
                View Details
              </Button>
              <Button
                size="small"
                color="success"
                onClick={(e) => {
                  e.stopPropagation();
                  viewEmployees(restaurant._id);
                }}
              >
                View Employees
              </Button>
              <Button
                size="small"
                color="secondary"
                onClick={(e) => handleEditClick(restaurant._id, e)}
              >
                Edit Restaurant
              </Button>
              <Button
                size="small"
                color="info"
                onClick={(e) => handleAddEmployeeClick(restaurant._id, e)}
              >
                Add Employee
              </Button>
            </CardActions>
          </Card>
        </Grid2>
      ))}
    </Grid2>
  );
};

export default RestaurantTable;
