import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { Container, Typography, Box, Card, CardContent } from '@mui/material';
import useGetRestaurantDetails from '../infrastructure/UseGetRestaurantDetails';
import Map from './map';
import Spinner from '../../components/Spinner';

// Mock function to fetch restaurant details

const RestaurantDetails = () => {
  const [coordinates, setCoordinates] = useState<[number, number] | null>(null);
  const { id } = useParams<{ id: string }>();
  const { data: restaurant, isLoading, error } = useGetRestaurantDetails(id);

  const geocodeAddress = async (address: string, city: string) => {
    const apiKey = '05c4679a8c0b4e19a8aa89fbbe1db857'; // Replace with your actual API key
    try {
      const response = await axios.get(
        `https://api.opencagedata.com/geocode/v1/json?q=${encodeURIComponent(
          `${address}, ${city}`,
        )}&key=${apiKey}`,
      );
      if (response.data.results.length > 0) {
        console.log('response', response.data.results[0]);
        const { lat, lng } = response.data.results[0].geometry;
        return [lat, lng];
      } else {
        setCoordinates(null);
        throw new Error('Location not found');
      }
    } catch (e) {
      console.log(e);
    }
  };

  useEffect(() => {
    if (restaurant) {
      console.log('restaurant', restaurant);
      geocodeAddress(restaurant.address, restaurant.location) // Suponiendo que también tienes la ciudad en el modelo
        // @ts-ignore
        .then((coords) => setCoordinates(coords))
        .catch((err) => console.error(err));
    }
  }, [restaurant]);
  if (isLoading) return <Spinner loading={isLoading} />;
  if (error) return <Typography>Error loading restaurant details</Typography>;
  if (!restaurant) return <Typography>Restaurant not found</Typography>;
  return (
    <Container sx={{ mt: 5 }}>
      <Card>
        <CardContent>
          <Typography variant="h4" component="h2" gutterBottom>
            {restaurant.name}
          </Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Address: {restaurant.address}, {restaurant.location}
          </Typography>
        </CardContent>
      </Card>

      {coordinates && restaurant && coordinates.length === 2 && (
        <Box sx={{ mt: 4 }}>
          <Typography variant="h5" gutterBottom>
            Restaurant Location
          </Typography>
          <Map coordinates={coordinates} restaurantName={restaurant.name} />
        </Box>
      )}
    </Container>
  );
};

export default RestaurantDetails;
