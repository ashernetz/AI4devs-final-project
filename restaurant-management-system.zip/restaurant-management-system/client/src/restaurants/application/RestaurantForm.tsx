import React, { useEffect, useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Button, TextField, Container, Box, Typography } from '@mui/material';
import axios from 'axios';
import useCreateRestaurant from '../infrastructure/useCreateRestaurant';
import toast from 'react-hot-toast';
const RestaurantForm = () => {
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [ownerId, setOwnerId] = useState(''); // Este puede ser un input o un select
  const [location, setLocation] = useState(''); // Este puede ser un input o un select

  const { mutate, isLoading, isError } = useCreateRestaurant();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await mutate({ name, address, ownerId, location });
      toast.success('Restaurant created successfully');
    } catch (e:any) {
      toast.error(e.message);
    }
  };

  /*
   * @todo
   *   - Agregar un auto completion
   *  - Agregar un select para el ownerId
   *  - validar si el ownerId es un usuario existente
   * **/
  return (
    <Container component="main" maxWidth="sm">
      <Box sx={{ mt: 8 }}>
        <Typography component="h1" variant="h5">
          Create Restaurant
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            margin="normal"
            required
            fullWidth
            label="Restaurant Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            label="Address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />

          <TextField
            margin="normal"
            required
            fullWidth
            label="location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            label="Owner ID"
            value={ownerId}
            onChange={(e) => setOwnerId(e.target.value)}
          />
          <Button type="submit" fullWidth variant="contained" sx={{ mt: 3 }}>
            Create Restaurant
          </Button>
        </form>
      </Box>
    </Container>
  );
};

export default RestaurantForm;
