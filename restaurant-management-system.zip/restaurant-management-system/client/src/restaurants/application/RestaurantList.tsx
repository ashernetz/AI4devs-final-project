import React, { useState } from 'react';
import { Box, Button, Typography, TextField } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import useRestaurantsApi from '../infrastructure/useGetRestaurants';
import RestaurantTable from './RestaurantTable';

const RestaurantList = () => {
  const { isLoading, data, error } = useRestaurantsApi();
  const [searchTerm, setSearchTerm] = useState('');

  if (isLoading) return <Typography>Loading...</Typography>;
  if (error) return <Typography>Error loading restaurants</Typography>;

  const filteredRestaurants = data
    ? data.filter((restaurant) =>
        restaurant.name.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    : [];

  return (
    <Box sx={{ position: 'relative', paddingBottom: '80px' }}>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 3,
        }}
      >
        <Typography variant="h4">Restaurant List</Typography>
        <Button
          variant="contained"
          color="primary"
          component={RouterLink}
          to="/restaurants/create"
        >
          Add Restaurant
        </Button>
      </Box>

      <TextField
        fullWidth
        variant="outlined"
        placeholder="Search a restaurant"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        sx={{ marginBottom: 3 }}
      />

      {!isLoading && filteredRestaurants.length > 0 ? (
        <RestaurantTable restaurants={filteredRestaurants} />
      ) : (
        <Typography>No restaurants found</Typography>
      )}
    </Box>
  );
};

export default RestaurantList;
