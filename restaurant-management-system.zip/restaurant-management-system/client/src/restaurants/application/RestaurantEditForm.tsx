import React, { useEffect, useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Button, TextField, Container, Box, Typography } from '@mui/material';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import useEditRestaurant from '../infrastructure/useEditRestaurant';
import useGetRestaurantDetails from '../infrastructure/UseGetRestaurantDetails';
import Spinner from '../../components/Spinner';

const RestaurantEditForm = () => {
  const { id } = useParams<{ id: string }>(); // Obtener el ID del restaurante desde la URL
  const {
    data: restaurant,
    isLoading: isLoadingDetails,
    error: errorDetails,
  } = useGetRestaurantDetails(id);
  // STate hooks
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [ownerId, setOwnerId] = useState(''); // Este puede ser un input o un select
  const [location, setLocation] = useState(''); // Este puede ser un input o un select
  console.log('restaurant', restaurant);
  // Hook para editar un restaurante

  const {
    mutate: updateRestaurant,
    isLoading: isUpdating,
    isError: isUpdateError,
  } = useEditRestaurant();

  const isLoading = isLoadingDetails || isUpdating;

  useEffect(() => {
    if (restaurant) {
      setName(restaurant.name);
      setAddress(restaurant.address);
      setOwnerId(restaurant.ownerId._id); // Asumiendo que el ownerId viene en el restaurante
      setLocation(restaurant.location);
    }
  }, [restaurant]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateRestaurant({ id, name, address, ownerId, location });
      toast.success('Restaurant updated successfully');
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  if (isLoading) return <Spinner loading={isLoading} />;
  if (isUpdateError || errorDetails)
    return <Typography>Error loading restaurant details.</Typography>;

  return (
    <Container component="main" maxWidth="sm">
      <Box sx={{ mt: 8 }}>
        <Typography component="h1" variant="h5">
          Edit Restaurant
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            margin="normal"
            required
            fullWidth
            label="Restaurant Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            label="Address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            label="Location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            label="Owner ID"
            value={ownerId}
            onChange={(e) => setOwnerId(e.target.value)}
          />
          <TextField
            margin="normal"
            disabled
            fullWidth
            label="Owner name"
            value={restaurant?.ownerId.name}
            onChange={(e) => setOwnerId(e.target.value)}
          />
          <Button type="submit" fullWidth variant="contained" sx={{ mt: 3 }}>
            {isUpdating ? 'Updating...' : 'Update Restaurant'}
          </Button>
          {isUpdateError && (
            <Typography color="error">Error updating restaurant.</Typography>
          )}
        </form>
      </Box>
    </Container>
  );
};

export default RestaurantEditForm;
