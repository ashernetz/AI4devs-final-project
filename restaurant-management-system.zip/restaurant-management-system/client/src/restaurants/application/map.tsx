import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

// Asegúrate de que el icono del marcador sea visible
import L from 'leaflet';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

interface MapProps {
  coordinates: [number, number];
  restaurantName: string;
}

const Map = ({ coordinates, restaurantName }: MapProps) => {
  console.log('coordinates', coordinates);
  console.log('restaurantName', restaurantName);
  if (!coordinates || !Array.isArray(coordinates) || coordinates.length !== 2) {
    return <div>Error: Invalid coordinates</div>;
  }

  // Configura el icono del marcador
  const DefaultIcon = L.icon({
    iconUrl: markerIcon,
    shadowUrl: markerShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41],
  });

  // Establece el icono por defecto
  L.Marker.prototype.options.icon = DefaultIcon;

  return (
    <MapContainer
      center={coordinates}
      zoom={13}
      scrollWheelZoom={false}
      style={{ height: '400px', width: '100%' }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <Marker position={coordinates}>
        <Popup>{restaurantName} is located here.</Popup>
      </Marker>
    </MapContainer>
  );
};

export default Map;
