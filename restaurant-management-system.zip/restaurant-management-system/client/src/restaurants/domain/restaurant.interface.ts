export interface Owner {
  _id: string;
  name: string;
}

export interface IRestaurant {
  name: string;
  location: string;
  address: string;
  ownerId: Owner;
  createdAt: Date;
  updatedAt: Date;
  employeeCount?: number;
  _id: string;
}

export interface RestaurantFormData {
  id?: string;
  name: string;
  location: string;
  address: string;
  ownerId: string;
}
