import { useMutation } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { useState } from 'react';
import { RestaurantFormData } from '../domain/restaurant.interface';
const useCreateRestaurant = () => {
  const [isLoading, setIsLoading] = useState(false);
  const mutation = useMutation({
    mutationFn: (params: RestaurantFormData) =>
      apiClient.post('/restaurants/register', params),

    onSettled: () => {
      setIsLoading(false);
    },
  });
  const postRestaurant = async (restaurantData: RestaurantFormData) => {
    setIsLoading(true);
    return mutation.mutateAsync(restaurantData);
  };

  return {
    isLoading,
    mutate: postRestaurant,
    isError: mutation.isError,
  };
};

export default useCreateRestaurant;
