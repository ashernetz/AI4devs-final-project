import { useQuery } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { IRestaurant } from '../domain/restaurant.interface';

const useGetRestaurantDetails = (id: string | undefined) => {
  const { isLoading, data, error } = useQuery({
    queryKey: ['restaurant', id],
    queryFn: () => fetchRestaurantById(id),
    enabled: !!id,
  });
  const fetchRestaurantById = async (
    id: string | undefined,
  ): Promise<IRestaurant> => {
    if (!id) throw new Error('Restaurant ID is required');
    const response = await apiClient.get(`/restaurants/restaurant/${id}`);
    return response.data;
  };
  return {
    isLoading,
    data,
    error,
  };
};

export default useGetRestaurantDetails;
