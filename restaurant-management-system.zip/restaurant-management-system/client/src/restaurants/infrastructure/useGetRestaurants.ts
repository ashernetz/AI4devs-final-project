import { useQuery } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { IRestaurant } from '../domain/restaurant.interface';

const useRestaurantsApi = () => {
  const { isLoading, data, error, refetch, isFetching } = useQuery({
    queryKey: ['restaurants'],
    queryFn: fetchRestaurants,
  });
  console.log('data', data);
  return {
    isLoading,
    data,
    error,
    refetch,
    isFetching,
  };
};
const fetchRestaurants = async (): Promise<IRestaurant[]> => {
  const response = await apiClient.get('/restaurants');
  return response.data;
};

export default useRestaurantsApi;
