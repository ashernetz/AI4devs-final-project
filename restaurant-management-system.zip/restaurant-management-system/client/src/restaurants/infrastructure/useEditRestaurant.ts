import { useMutation } from '@tanstack/react-query';
import apiClient from '../../services/axios';
import { useState } from 'react';
import { RestaurantFormData } from '../domain/restaurant.interface';

const useEditRestaurant = () => {
  const [isLoading, setIsLoading] = useState(false);
  const mutation = useMutation({
    mutationFn: (params: RestaurantFormData) =>
      apiClient.patch(`/restaurants/update/${params.id}`, params),

    onSettled: () => {
      setIsLoading(false);
    },
  });
  const editRestaurant = async (restaurantData: {
    address: string;
    name: string;
    location: string;
    id: string | undefined;
    ownerId: string;
  }) => {
    setIsLoading(true);
    return mutation.mutateAsync(restaurantData);
  };

  return {
    isLoading,
    mutate: editRestaurant,
    isError: mutation.isError,
  };
};

export default useEditRestaurant;
