import { useMutation } from '@tanstack/react-query';
import { loginUser } from './auth.service';

export const useLogin = () => {
  // @ts-ignore
  return useMutation(loginUser, {
    onSuccess: (data: any) => {
      // Guardar el token en localStorage
      localStorage.setItem('token', data.token);

      // Redirigir al Dashboard o alguna otra página
      window.location.href = '/dashboard';
    },
    onError: (error: Error) => {
      console.error('Error al iniciar sesión:', error);
      // Puedes mostrar un mensaje de error aquí
    },
  });
};
