import { LoginData } from '../domain/login.interface';
import apiClient from '../../services/axios';

export const loginUser = async (loginData: LoginData): Promise<any> => {
  const response = await apiClient.post('/users/login', loginData);
  return response.data; // Esto devolverá el token y otros datos de la respuesta
};
