import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '@mui/material';

const LogoutLink = () => {
  const { logout } = useAuth(); // Acceder a la función de logout desde el contexto

  return (
    <Button color="secondary" onClick={logout}>
      Logout
    </Button>
  );
};

export default LogoutLink;
