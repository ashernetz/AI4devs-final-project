export interface User {
  id: string;
  name: string;
  email: string;
  role: 'superadmin' | 'admin' | 'manager' | 'staff' | 'customer' | 'owner';
  _id?: string;
}

export interface LoginSuccessResponse {
  user: User;
  token: string;
}
