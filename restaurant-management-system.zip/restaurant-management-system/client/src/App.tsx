import logo from './logo.svg';
import './App.css';
import AppRoutes from './routes/AppRoutes';
import { Toaster } from 'react-hot-toast';
import { useLocation } from 'react-router-dom';
import Navbar from './components/NavBar';
import { Container } from '@mui/material';
function App() {
  const location = useLocation();
  const showNavbar = location.pathname !== '/login';
  return (
    <div className="App">
      <Toaster />
      {showNavbar && <Navbar />}
      <Container maxWidth="lg" sx={{ marginTop: '6rem', marginBottom: '2rem' }}>
        <AppRoutes />
      </Container>
    </div>
  );
}

export default App;
