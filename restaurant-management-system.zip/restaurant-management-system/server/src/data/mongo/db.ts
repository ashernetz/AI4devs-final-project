import * as mongoose from 'mongoose';

interface connectionOptions {
  mongoUrl: string;
  dbName: string;
}

export class MongoDataBase {
  static async connect(options: connectionOptions) {
    const { mongoUrl, dbName } = options;
    try {
      await mongoose.connect(
          mongoUrl,
          {
            dbName: dbName,
          },
      );
      return true;
    } catch (e) {
      console.log(e);
      throw e;
    }
  }
}
