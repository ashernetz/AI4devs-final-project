import mongoose, { Document, Schema } from 'mongoose';

export interface IUser extends Document {
  name: string;
  email: string;
  password: string;
  role: 'superadmin' | 'admin' | 'manager' | 'staff' | 'customer' | 'owner'; // Added 'superadmin'
  restaurantId: string;
  createdAt: Date;
  updatedAt: Date;
  status: 'active' | 'inactive';
}

const UserSchema: Schema = new Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: {
    type: String,
    enum: ['superadmin', 'admin', 'manager', 'staff', 'customer', 'owner'],
    default: 'customer',
  }, // Añadir 'owner' como opción de rol
  restaurantId: {
    type: Schema.Types.ObjectId,
    ref: 'Restaurant',
    required: false,
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  status: { type: String, enum: ['active', 'inactive'], default: 'active' },
});
export const UserModel = mongoose.model<IUser>('User', UserSchema);
