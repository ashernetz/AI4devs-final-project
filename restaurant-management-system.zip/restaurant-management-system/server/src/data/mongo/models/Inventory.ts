import mongoose, { Document, Schema } from 'mongoose';

export interface IInventory extends Document {
  restaurantId: mongoose.Types.ObjectId;
  productId: mongoose.Types.ObjectId;
  quantity: number; // Cantidad disponible
  minQuantity: number; // Cantidad mínima antes de emitir una advertencia de bajo stock
  createdAt: Date;
  updatedAt: Date;
}

const InventorySchema: Schema = new Schema({
  restaurantId: {
    type: Schema.Types.ObjectId,
    ref: 'Restaurant',
    required: true,
  },
  productId: { type: Schema.Types.ObjectId, ref: 'Product', required: true },
  quantity: { type: Number, required: true },
  minQuantity: { type: Number, required: true, default: 5 }, // Umbral para advertencias de bajo stock
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

export const InventoryModel = mongoose.model<IInventory>(
  'Inventory',
  InventorySchema,
);
