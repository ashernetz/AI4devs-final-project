import mongoose, { Document, Schema } from 'mongoose';

export interface IUserRole extends Document {
  userId: mongoose.Types.ObjectId; // Referencia al usuario
  restaurantId?: mongoose.Types.ObjectId;
  role: 'superadmin' | 'owner' | 'manager' | 'staff' | 'admin';
  createdAt: Date;
  updatedAt: Date;
}

const UserRoleSchema: Schema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  restaurantId: {
    type: Schema.Types.ObjectId,
    ref: 'Restaurant',
    required: function(this: any) {
      return this.role !== 'superadmin'; // SuperAdmin doesn't need a restaurantId
    },
  },
  role: {
    type: String,
    enum: ['superadmin', 'owner', 'manager', 'staff', 'admin'],
    required: true,
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

export const UserRole = mongoose.model<IUserRole>('UserRole', UserRoleSchema);
