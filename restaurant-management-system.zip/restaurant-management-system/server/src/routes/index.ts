import express, { Router, Request, Response } from 'express';
import RestaurantRoutes from '../presentation/multitenant/routes';
import UserRoutes from '../presentation/users/routes';
import OrderRoutes from '../presentation/orders/routes';
import ProductRoutes from '../presentation/product/routes';
import CategoryRoutes from '../presentation/category/routes';
import OrderItemRoutes from '../presentation/orderItem/routes';
import InventoryRoutes from '../presentation/Inventory/routes';
import cors from 'cors';
const corsOptions = {
  origin: 'http://example.com',
  optionsSuccessStatus: 200, // some legacy browsers (IE11, various SmartTVs) choke on 204
};
export class AppRoutes {
  static get routes(): Router {
    const router = Router();

    // Definir las rutas
    router.get('/', cors(corsOptions), (req: Request, res: Response) =>
      res.send('API is running'),
    );

    //restaurant routes
    router.use('/api/restaurants', RestaurantRoutes.routes);
    router.use('/api/users', UserRoutes.routes);
    router.use('/api/orders', OrderRoutes.routes);
    router.use('/api/order-item', OrderItemRoutes.routes);
    router.use('/api/product', ProductRoutes.routes);
    router.use('/api/categories', CategoryRoutes.routes);
    router.use('/api/inventory', InventoryRoutes.routes);

    return router;
  }
}
