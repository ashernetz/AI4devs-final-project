import { Request, Response, NextFunction } from 'express';
import { UserModel, UserRole as UserRoleModel } from '../../data/index';

// Función para validar si el usuario puede agregar empleados
const canAddEmployee = async (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  const user = JSON.parse(<string>req.headers['user']);
  console.log('req', user);
  //const { user } = req; // Ahora req.user está definido correctamente
  const { restaurantId } = req.params; // ID del restaurante donde se intenta agregar un empleado

  if (!user) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  try {
    // Verificar si el usuario es superadmin
    if (user.role === 'superadmin') {
      return next(); // Permitir si es superadmin
    }

    // Verificar si el usuario tiene un rol válido en el restaurante específico
    const userRole = await UserRoleModel.findOne({
      userId: user.id,
      restaurantId,
    });
    if (!userRole) {
      return res
        .status(403)
        .json({ message: 'User does not belong to this restaurant' });
    }

    // Validar si el usuario tiene un rol adecuado (admin o owner)
    if (userRole.role === 'owner' || userRole.role === 'admin') {
      return next(); // El usuario tiene permiso para agregar empleados
    }

    return res
      .status(403)
      .json({ message: 'User does not have permission to add employees' });
  } catch (error) {
    return res.status(500).json({ message: 'Internal server error', error });
  }
};

export default canAddEmployee;
