import { JwtAdapter } from '../../config/jwt.adapter';

export const authUser = async (
  req: Request,
  res: Response,
): Promise<Response> => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });

    if (user && (await user.matchPassword(password))) {
      return res.json({
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        token: JwtAdapter.generateToken(user._id),
      });
    } else {
      return res.status(401).json({ message: 'Credenciales inválidas' });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Error en la autenticación' });
  }
};
