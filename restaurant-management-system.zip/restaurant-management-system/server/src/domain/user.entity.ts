export class UserEntity {
  private static readonly requiredFields: string[] = [
    'id',
    'name',
    'email',
    'password',
    'role',
  ];
  constructor(
    public id: string,
    public name: string,
    public email: string,
    public password: string,
    public role: string[],
    public _id?: string,
  ) {}

  static fromObject(obj: { [key: string]: any }): UserEntity {
    const { id = '', _id = '', name, email, password, img, role } = obj;
    for (const field of this.requiredFields) {
      if (!(field in obj)) {
        throw new Error(`UserEntity.fromObject: ${field} is required`);
      }
    }
    return new UserEntity(id, name, email, password, role, _id);
  }
}
