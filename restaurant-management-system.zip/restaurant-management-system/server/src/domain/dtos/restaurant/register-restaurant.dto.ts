export class RegisterRestaurantDto {
  private constructor(
    public name: string,
    public location: string,
    public ownerId: string,
    public address?: string
  ) {}

  static create(obj: {
    [name: string]: any;
  }): [string?, RegisterRestaurantDto?] {
    const { name, location, ownerId, address } = obj;
    if (!name || !location || !ownerId || !address) {
      //throw new Error('RegisterRestaurantDto.create: missing required fields');
      return ['missing required fields'];
    }
    return [undefined, new RegisterRestaurantDto(name, location, ownerId, address)];
  }
}
