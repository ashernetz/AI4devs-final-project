import { validateSync } from 'class-validator';

export class UpdateRestaurantDto {
  private constructor(
    public id: string,
    public name: string,
    public location: string,
    public ownerId: string,
    public address: string,
  ) {}

  static create(obj: { [name: string]: any }): [string?, UpdateRestaurantDto?] {
    const { id, name, location, ownerId, address } = obj;
    const dto = new UpdateRestaurantDto(id, name, location, ownerId, address);
    const errors = validateSync(dto);
    if (errors.length > 0) {
      return [errors.toString()];
    }
    return [undefined, dto];
  }
}
