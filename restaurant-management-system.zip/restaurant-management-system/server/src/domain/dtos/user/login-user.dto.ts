import { regularExps } from '../../../config/regular-exp';

export class LoginUserDto {
  private constructor(public email: string, public password: string) {}

  static create(obj: { [name: string]: any }): [string?, LoginUserDto?] {
    const { email, password } = obj;
    console.log(email);
    if (!email || !password) {
      //throw new Error('RegisterUserDto.create: missing required fields');
      return ['missing required fields'];
    }
    if (regularExps.email.test(email) === false) {
      //throw new Error('RegisterUserDto.create: invalid email');
      return ['invalid email'];
    }
    return [undefined, new LoginUserDto(email, password)];
  }
}
