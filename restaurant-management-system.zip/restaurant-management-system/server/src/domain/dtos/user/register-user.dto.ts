import { regularExps } from '../../../config/regular-exp';

export class RegisterUserDto {
  private constructor(
    public name: string,
    public email: string,
    public password: string,
    public role: string,
    public restaurantId?: string,
  ) {}

  static create(obj: { [name: string]: any }): [string?, RegisterUserDto?] {
    const { name, email, password, role, restaurantId } = obj;
    if (!name || !email || !password || !role) {
      //throw new Error('RegisterUserDto.create: missing required fields');
      return ['missing required fields'];
    }
    if (regularExps.email.test(email) === false) {
      //throw new Error('RegisterUserDto.create: invalid email');
      return ['invalid email'];
    }
    return [
      undefined,
      new RegisterUserDto(name, email, password, role, restaurantId),
    ];
  }
}
