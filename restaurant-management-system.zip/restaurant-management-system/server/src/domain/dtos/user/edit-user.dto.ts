import { regularExps } from '../../../config/regular-exp';

export class EditUserDto {
  private constructor(
    public id: string,
    public name: string,
    public email: string,
    public password: string,
    public role: string,
    public restaurantId?: string,
  ) {}

  static create(obj: { [name: string]: any }): [string?, EditUserDto?] {
    const { name, email, password, role, restaurantId } = obj;
    if (email && regularExps.email.test(email) === false) {
      return ['invalid email'];
    }
    return [
      undefined,
      new EditUserDto(name, email, password, role, restaurantId),
    ];
  }
}
