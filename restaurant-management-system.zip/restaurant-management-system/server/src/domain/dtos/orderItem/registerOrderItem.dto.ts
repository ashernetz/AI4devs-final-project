import { IsNotEmpty, IsNumber, IsMongoId } from 'class-validator';
import mongoose from 'mongoose';

export class RegisterOrderItemDto {
  private constructor(
    public orderId: mongoose.Types.ObjectId,
    public productId: mongoose.Types.ObjectId,
    public quantity: number,
    public price: number,
    public description?: string,
  ) {}

  static create(obj: { [key: string]: any }): [string?, RegisterOrderItemDto?] {
    const { orderId, productId, quantity, price, description } = obj;
    if (!orderId || !productId || !quantity || !price) {
      return ['missing required fields'];
    }
    if (
      !mongoose.Types.ObjectId.isValid(orderId) ||
      !mongoose.Types.ObjectId.isValid(productId)
    ) {
      return ['invalid ObjectId'];
    }
    if (typeof quantity !== 'number' || typeof price !== 'number') {
      return ['quantity and price must be numbers'];
    }
    return [
      undefined,
      new RegisterOrderItemDto(
        orderId,
        productId,
        quantity,
        price,
        description,
      ),
    ];
  }
}
