import { validateSync } from 'class-validator';

export class EditProductDto {
  constructor(
    public productId: string,
    public restaurantId: string,
    public name: string,
    public description: string,
    public price: string,
    public categoryId: string,
  ) {}

  static create(body: any): [string | null, EditProductDto | null] {
    const {
      productId,
      restaurantId,
      name,
      price,
      categoryId,
      description,
    } = body;
    const dto = new EditProductDto(
      productId,
      restaurantId,
      name,
      description,
      price,
      categoryId,
    );
    const errors = validateSync(dto);
    if (errors.length > 0) {
      return [errors.toString(), null];
    }
    return [null, dto];
  }
}
