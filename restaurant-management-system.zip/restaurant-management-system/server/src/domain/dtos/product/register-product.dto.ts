import { validateSync } from 'class-validator';

export class RegisterProductDto {
  constructor(
    public restaurantId: string,
    public name: string,
    public description: string,
    public price: string,
    public categoryId: string,
  ) {}

  static create(body: any): [string | null, RegisterProductDto | null] {
    const { restaurantId, name, price, categoryId, description } = body;
    const dto = new RegisterProductDto(
      restaurantId,
      name,
      description,
      price,
      categoryId,
    );
    const errors = validateSync(dto);
    if (errors.length > 0) {
      return [errors.toString(), null];
    }
    return [null, dto];
  }
}
