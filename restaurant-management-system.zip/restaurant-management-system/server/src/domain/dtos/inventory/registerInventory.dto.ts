// src/domain/dtos/inventory/registerInventory.dto.ts

export class RegisterInventoryDto {
  private constructor(
    public restaurantId: string,
    public productId: string,
    public quantity: number,
    public minQuantity: number,
  ) {}

  static create(obj: { [key: string]: any }): [string?, RegisterInventoryDto?] {
    const { restaurantId, productId, quantity, minQuantity } = obj;
    console.log(restaurantId, productId, quantity, minQuantity);
    if (
      !restaurantId ||
      !productId ||
      quantity === undefined ||
      minQuantity === undefined
    ) {
      return ['missing required fields'];
    }
    if (typeof quantity !== 'number' || typeof minQuantity !== 'number') {
      return ['quantity and minQuantity must be numbers'];
    }
    return [
      undefined,
      new RegisterInventoryDto(restaurantId, productId, quantity, minQuantity),
    ];
  }
}
