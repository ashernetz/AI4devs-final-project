export class RegisterOrderDto {
  private constructor(
    public restaurantId: string,
    public userId: string,
    public totalAmount: number,
    public status: 'pending' | 'inProgress' | 'completed' | 'cancelled',
    public tableNumber?: number,
  ) {}

  static create(obj: { [key: string]: any }): [string?, RegisterOrderDto?] {
    const { restaurantId, userId, totalAmount, tableNumber = 0 } = obj;
    const status = 'inProgress';
    console.log(restaurantId, userId, totalAmount);
    if (!restaurantId || !userId || totalAmount < 0) {
      return ['missing required fields'];
    }
    if (typeof totalAmount !== 'number') {
      return ['totalAmount must be a number'];
    }

    if (!['pending', 'inProgress', 'completed', 'cancelled'].includes(status)) {
      return ['invalid status'];
    }

    return [
      undefined,
      new RegisterOrderDto(
        restaurantId,
        userId,
        totalAmount,
        status,
        tableNumber,
      ),
    ];
  }
}
