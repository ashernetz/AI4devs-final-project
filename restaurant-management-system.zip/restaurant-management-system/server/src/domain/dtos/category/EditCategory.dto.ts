// src/domain/dtos/category/EditCategory.dto.ts
export class EditCategoryDto {
  private constructor(public id: string, public name: string, public description: string) {}

  static create(obj: { [name: string]: any }): [string?, EditCategoryDto?] {
    const { id, name, description } = obj;
    if (!id || !name || !description) {
      return ['missing required fields'];
    }
    return [undefined, new EditCategoryDto(id, name, description)];
  }
}
