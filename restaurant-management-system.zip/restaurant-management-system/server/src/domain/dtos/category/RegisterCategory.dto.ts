export class RegisterCategoryDto {
  private constructor(public name: string, public description: string) {}

  static create(obj: { [name: string]: any }): [string?, RegisterCategoryDto?] {
    const { name, description } = obj;
    if (!name || !description) {
      return ['missing required fields'];
    }
    return [undefined, new RegisterCategoryDto(name, description)];
  }
}
