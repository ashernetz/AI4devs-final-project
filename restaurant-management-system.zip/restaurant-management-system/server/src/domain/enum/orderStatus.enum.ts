export enum OrderStatus {
  Pending = 'pending',
  InProgress = 'inProgress',
  Completed = 'completed',
  Cancelled = 'cancelled',
}
