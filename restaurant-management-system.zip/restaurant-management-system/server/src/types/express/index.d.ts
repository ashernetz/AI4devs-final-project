import { IUser } from '../../models/User'; // Ajusta la ruta al modelo de User

declare global {
  namespace Express {
    interface Request {
      user?: IUser; // Agrega el tipo de usuario autenticado
    }
  }
}
