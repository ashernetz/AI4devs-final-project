import jwt from 'jsonwebtoken';
import { envs } from './envs';

/**
 * VALIDATE TOKEN: https://jwt.io/
 * */

export class JwtAdapter {
  private static readonly secretKey = envs.JWT_SEED;

  // Implementación del método sign.
  static sign(payload: any): string {
    return jwt.sign(payload, this.secretKey, { expiresIn: '2h' });
  }

  static async generateToken(
    payload: any,
    duration: string = '2h',
  ): Promise<string | null> {
    return new Promise((resolve, reject) => {
      jwt.sign(
        payload,
        this.secretKey,
        { expiresIn: duration },
        (err, token) => {
          if (err) {
            //reject(new Error('Error generating token'));
            return resolve(null);
          }
          resolve(token!);
        },
      );
    });
  }

  static validateToken(token: string): any {
    return jwt.verify(token, this.secretKey);
  }
}
