import { Router } from 'express';
import ProductController from './controller';
import ProductService from '../services/product.service';

class ProductRoutes {
  static get routes(): Router {
    const router = Router();
    const productService = new ProductService();
    const controller = new ProductController(productService);
    router.post('/', controller.getAllProducts);
    router.post('/details', controller.getProductById);
    router.post('/register', controller.registerProduct);
    router.patch('/edit/:id', controller.editProduct);
    router.delete('/delete/:id', controller.deleteProduct);
    return router;
  }
}

export default ProductRoutes;
