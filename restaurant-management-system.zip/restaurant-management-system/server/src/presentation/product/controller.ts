import { Request, Response } from 'express';
import { RegisterProductDto } from '../../domain/dtos/product/register-product.dto';
import { CustomError } from '../../domain/errors/custom.error';
import ProductService from '../services/product.service';
import { EditProductDto } from '../../domain/dtos/product/edit-product.dto';

export default class ProductController {
  constructor(public readonly productService: ProductService) {}
  private handleError = (error: any, res: Response) => {
    if (error instanceof CustomError) {
      return res.status(error.statusCode).json({ error: error.message });
    }
    return res.status(500).json({ error: error.message });
  };

  registerProduct = (req: Request, res: Response) => {
    const { body } = req;
    console.log('body', body);
    const registerProductDto = RegisterProductDto.create(body);
    const [error, dto] = registerProductDto;
    if (error) {
      return res.status(400).json({ error });
    }

    this.productService
      .registerProduct(dto!)
      .then((product: any) => {
        res.json(product);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  editProduct = (req: Request, res: Response) => {
    console.log('here');
    const { id } = req.params;
    const { body } = req;
    console.log('body', body);
    const registerProductDto = EditProductDto.create({
      ...body,
      productId: id,
    });
    const [error, dto] = registerProductDto;
    if (error) {
      return res.status(400).json({ error });
    }

    this.productService
      .updateProduct(dto!)
      .then((product: any) => {
        res.json(product);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  deleteProduct = (req: Request, res: Response) => {
    const { id } = req.params;
    this.productService
      .deleteProduct(id)
      .then((product) => {
        res.json(product);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  getAllProducts = (req: Request, res: Response) => {
    const { restaurantId } = req.body;
    this.productService
      .getAllProducts(restaurantId)
      .then((products) => {
        res.json(products);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  getProductById = (req: Request, res: Response) => {
    const { id, restaurantId } = req.body;
    this.productService
      .getProductById(id, restaurantId)
      .then((product) => {
        res.json(product);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };
}
