import { Router } from 'express';
import RestaurantController from './controller';
import RestaurantService from '../services/restaurant.service';

class RestaurantRoutes {
  static get routes(): Router {
    const router = Router();
    const restaurantService = new RestaurantService();
    const controller = new RestaurantController(restaurantService);

    router.get('/', controller.getAllRestaurants);
    router.get('/owner/:ownerId', controller.getByOwnerId);
    router.get('/restaurant/:id', controller.getRestaurantById);
    router.post('/register', controller.registerRestaurant);
    router.patch('/update/:id', controller.updateRestaurant);
    router.delete('/delete/:id', controller.deleteRestaurant);
    return router;
  }
}

export default RestaurantRoutes;
