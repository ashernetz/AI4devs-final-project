// src/controllers/RestaurantController.ts
import { Request, Response } from 'express';
import { RegisterRestaurantDto } from '../../domain/dtos/restaurant/register-restaurant.dto';
import { CustomError } from '../../domain/errors/custom.error';
import RestaurantService from '../services/restaurant.service';
import { UpdateRestaurantDto } from '../../domain/dtos/restaurant/update-restaurant.dto';

export default class RestaurantController {
  constructor(public readonly restaurantService: RestaurantService) {}
  private handleError = (error: any, res: Response) => {
    if (error instanceof CustomError) {
      return res.status(error.statusCode).json({ error: error.message });
    }
    return res.status(500).json({ error: error.message });
  };

  registerRestaurant = (req: Request, res: Response) => {
    const { body } = req;
    console.log('body', body);
    const registerRestaurantDto = RegisterRestaurantDto.create(body);
    const [error, dto] = registerRestaurantDto;
    if (error) {
      return res.status(400).json({ error });
    }
    this.restaurantService
      .registerRestaurant(dto!)
      .then((restaurant) => {
        res.json(restaurant);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  updateRestaurant = (req: Request, res: Response) => {
    const { id } = req.params;
    const { body } = req;
    const registerRestaurantDto = UpdateRestaurantDto.create({
      ...body,
      id,
    });
    const [error, dto] = registerRestaurantDto;
    if (error) {
      return res.status(400).json({ error });
    }
    console.log('dto', dto);
    this.restaurantService
      .updateRestaurant(dto!)
      .then((restaurant) => {
        res.json(restaurant);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  getAllRestaurants = (req: Request, res: Response) => {
    this.restaurantService
      .getAllRestaurants()
      .then((restaurants) => {
        res.json(restaurants);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  getRestaurantById = (req: Request, res: Response) => {
    const { id } = req.params;
    this.restaurantService
      .getRestaurantById(id)
      .then((restaurant) => {
        res.json(restaurant);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  getByOwnerId = (req: Request, res: Response) => {
    const { ownerId } = req.params;
    this.restaurantService
      .getByOwnerId(ownerId.toString())
      .then((restaurants) => {
        res.json(restaurants);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  deleteRestaurant = (req: Request, res: Response) => {
    const { id } = req.params;
    this.restaurantService
      .deleteRestaurant(id)
      .then((restaurant) => {
        res.json(restaurant);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };
}
