import { Router } from 'express';
import InventoryController from './controller';
import InventoryService from "../services/inventory.service";

class InventoryRoutes {
  static get routes(): Router {
    const service = new InventoryService();
    const controller = new InventoryController(service);
    const router = Router();
    router.post('/', controller.addInventory);
    router.put('/update-stock', controller.updateInventoryOnOrder);
    router.get('/:restaurantId', controller.getInventorybyRestaurantId);
    // Definir las rutas
    return router;
  }
}

export default InventoryRoutes;
