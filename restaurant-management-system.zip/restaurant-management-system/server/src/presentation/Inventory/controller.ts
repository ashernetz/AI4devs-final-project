import { Request, Response } from 'express';
import { CustomError } from '../../domain/errors/custom.error';
import InventoryService from '../services/inventory.service';
import { RegisterInventoryDto } from '../../domain/dtos/inventory/registerInventory.dto';

export default class InventoryController {
  constructor(public readonly inventoryService: InventoryService) {}

  private handleError = (error: any, res: Response) => {
    if (error instanceof CustomError) {
      return res.status(error.statusCode).json({ error: error.message });
    }
    return res.status(500).json({ error: error.message });
  };
  addInventory = (req: Request, res: Response) => {
    const { body } = req;
    const registerInventoryDto = RegisterInventoryDto.create({
      ...body,
      quantity: parseInt(body.quantity),
      minQuantity: parseInt(body.minQuantity),
    });
    const [error, dto] = registerInventoryDto;
    if (error) {
      return res.status(400).json({ error });
    }
    console.log('dto', dto);
    this.inventoryService
      .addInventory(dto!)
      .then((inventory) => {
        res.json(inventory);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };
  updateInventoryOnOrder = (req: Request, res: Response) => {};
  getInventorybyRestaurantId = (req: Request, res: Response) => {
    const { restaurantId } = req.params;
    this.inventoryService
      .getInventoryByRestaurantId(restaurantId)
      .then((inventory: any) => {
        res.json(inventory);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };
}
