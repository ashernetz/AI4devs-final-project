import { UserModel, UserRole } from '../../data/index';
import { RegisterUserDto } from '../../domain/dtos/user/register-user.dto';
import { CustomError } from '../../domain/errors/custom.error';
import { bycriptAdapter } from '../../config/bycrypt.adapter';
import { LoginUserDto } from '../../domain/dtos/user/login-user.dto';
import { JwtAdapter } from '../../config/jwt.adapter';
import { UserEntity } from '../../domain/user.entity';
import { EditUserDto } from '../../domain/dtos/user/edit-user.dto';

class UserService {
  constructor() {}

  public async registerUser(registerUserDto: RegisterUserDto) {
    const hasUser = await this.hasUser(registerUserDto);
    if (hasUser) {
      throw new Error('User already exists');
    }

    try {
      const user = new UserModel(registerUserDto);
      // encrypt password
      user.password = bycriptAdapter.hash(user.password);
      await user.save();

      // create user role
      const userRole = new UserRole({
        userId: user._id,
        role: user.role,
        restaurantId: registerUserDto.restaurantId,
      });
      await userRole.save();
      return user;
    } catch (e) {
      console.log(e);
      throw CustomError.internalServerError(`Error creating user ${e}`);
    }
  }

  public async updateUser(editUserDto: EditUserDto) {
    try {
      const user = await UserModel.findById(editUserDto.id);
      if (!user) {
        throw CustomError.notFound(`User with id ${editUserDto.id} not found`);
      }
      user.name = editUserDto.name;
      user.email = editUserDto.email;
      // @ts-ignore
      user.role = editUserDto.role;
      // @ts-ignore
      user.restaurantId = editUserDto.restaurantId;
      await user.save();
      return user;
    } catch (e) {
      throw CustomError.internalServerError(`Error updating user ${e}`);
    }
  }

  public async loginUser(loginUserDto: LoginUserDto) {
    const user = await UserModel.findOne({ email: loginUserDto.email });
    const hasUser = Boolean(user);
    if (!hasUser) {
      throw CustomError.badRequest('User not found');
    }

    // isMatch bcrypt compare(password, encriptedPassword)
    if (!bycriptAdapter.compare(loginUserDto.password, user!.password)) {
      throw CustomError.badRequest('Invalid password');
    }

    const { password, ...userEntity } = UserEntity.fromObject(user!);
    const token = await JwtAdapter.generateToken({
      id: user!.id,
      email: user!.email,
    });
    if (!token) {
      throw CustomError.internalServerError('Error generating token');
    }
    return {
      user: userEntity,
      token: token,
    };
  }

  public async getUsersByRestaurant(restaurantId: string) {
    const users = await UserModel.find({ restaurantId });
    return users;
  }

  hasUser = async (registerUserDto: RegisterUserDto) => {
    const user = await UserModel.findOne({
      email: registerUserDto.email,
    });
    return Boolean(user);
  };

  getUsersByRole = async (role: string) => {
    const users = await UserModel.find({ role });
    return users;
  };

  getUserDetails = async (
    employeeId: string,
    role: string,
    restaurantId: string,
  ) => {
    try {
      const employee = await UserModel.findOne({
        _id: employeeId,
        restaurantId: restaurantId,
      });
      console.log('the employee', employee);

      if (!employee) {
        throw CustomError.notFound('Employee not found');
      }

      console.log('employee', employee);
      console.log('the role', role);
      if (role === 'superadmin') {
        console.log('in the suparadmin');
        return employee;
      }

      if (
        ['owner', 'admin', 'manager'].includes(role) &&
        employee.restaurantId.toString() === restaurantId.toString()
      ) {
        return employee;
      }
      throw CustomError.forbidden('You are not authorized to view this user');
    } catch (e) {
      throw CustomError.internalServerError(`Error getting user details ${e}`);
    }
  };
}

export default UserService;
