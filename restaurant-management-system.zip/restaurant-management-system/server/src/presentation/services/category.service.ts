import { RegisterCategoryDto } from '../../domain/dtos/category/RegisterCategory.dto';
import { CustomError } from '../../domain/errors/custom.error';
import { CategoryModel } from '../../data';
import { EditCategoryDto } from '../../domain/dtos/category/EditCategory.dto';

class CategoryService {
  constructor() {}
  public async registerCategory(registerCategoryDto: RegisterCategoryDto) {
    try {
      const category = new CategoryModel(registerCategoryDto);
      await category.save();
      return category;
    } catch (e) {
      console.log(e);
      throw CustomError.internalServerError(`Error creating user ${e}`);
    }
  }

  public async editCategory(editCategoryDto: EditCategoryDto) {
    try {
      const category = await CategoryModel.findById(editCategoryDto.id);
      if (!category) {
        throw CustomError.notFound(
          `Category with id ${editCategoryDto.id} not found`,
        );
      }
      category.name = editCategoryDto.name;
      category.description = editCategoryDto.description;
      await category.save();
      return category;
    } catch (e) {
      throw CustomError.internalServerError(`Error creating user ${e}`);
    }
  }

  getAllCategories = async () => {
    try {
      const categories = await CategoryModel.find();
      return categories;
    } catch (e) {
      throw CustomError.internalServerError(`Error creating user ${e}`);
    }
  };

  getCategoryById = async (id: string) => {
    try {
      return await CategoryModel.findById(id);
    } catch (e) {
      throw CustomError.internalServerError(`error getting the category ${e}`);
    }
  };

  getByOwnerId = async (ownerId: string) => {
    try {
      return [];
    } catch (e) {
      throw CustomError.internalServerError(`Error creating user ${e}`);
    }
  };
}

export default CategoryService;
