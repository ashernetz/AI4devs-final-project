import { orderItemModel, OrderModel, OrderStatus } from '../../data/index';
import { CustomError } from '../../domain/errors/custom.error';
import { RegisterOrderDto } from '../../domain/dtos/order/RegisterOrder.dto';

class OrderService {
  constructor() {}

  async registerOrder(registerOrderDto: RegisterOrderDto) {
    try {
      const order = new OrderModel(registerOrderDto);
      await order.save();
      return order;
    } catch (e) {
      throw CustomError.internalServerError(`Error creating order ${e}`);
    }
  }

  async getAllOrders() {
    try {
      const orders = await OrderModel.find();
      return orders;
    } catch (e) {
      throw CustomError.internalServerError(`Error getting orders ${e}`);
    }
  }

  async getOrdersByRestaurant(restaurantId: string) {
    try {
      const orders = await OrderModel.find({ restaurantId });
      // Para cada orden, contar el número de productos
      const ordersWithProductCount = await Promise.all(
        orders.map(async (order) => {
          /* const productCount = await orderItemModel.countDocuments({
            orderId: order._id,
          });*/
          const orderItems = await orderItemModel.find({ orderId: order._id });
          const totalAmount = orderItems.reduce((acc, item) => {
            return acc + item.quantity * item.price;
          }, 0);

          // Contar el número de productos
          const productCount = orderItems.length;

          return { ...order.toObject(), totalAmount, productCount };
        }),
      );
      return ordersWithProductCount;
    } catch (e) {
      throw CustomError.internalServerError(`Error getting orders ${e}`);
    }
  }

  async getOrdersByTable(tableNumber: string, restaurantId: string) {
    try {
      console.log(tableNumber, restaurantId);
      const orders = await OrderModel.find({ tableNumber, restaurantId });
      return orders;
    } catch (e) {
      throw CustomError.internalServerError(`Error getting orders ${e}`);
    }
  }

  async updateOrderStatus(orderId: string, status: OrderStatus) {
    try {
      const order = await OrderModel.findById(orderId);
      if (!order) {
        throw CustomError.notFound(`Order with id ${orderId} not found`);
      }
      order.status = status;
      await order.save();
      return order;
    } catch (e) {
      throw CustomError.internalServerError(`Error updating order ${e}`);
    }
  }

  async deleteOrder(orderId: string) {
    try {
      const order = await OrderModel.findById(orderId);
      if (!order) {
        throw CustomError.notFound(`Order with id ${orderId} not found`);
      }
      await order.deleteOne({
        _id: orderId,
      });
      return true;
    } catch (e) {
      throw CustomError.internalServerError(`Error deleting order ${e}`);
    }
  }

  async getOrdersByStatus(status: OrderStatus, restaurantId: string) {
    try {
      const orders = await OrderModel.find({ status, restaurantId });
      return orders;
    } catch (e) {
      throw CustomError.internalServerError(`Error getting orders ${e}`);
    }
  }

  async getOrderDetails(orderId: string) {
    try {
      // Buscar la orden por su ID y popular la información del usuario que emitió la orden
      const order = await OrderModel.findById(orderId)
        .populate('userId', 'name email') // Obtener la información del usuario que emitió la orden
        .populate('restaurantId', 'name'); // Si es necesario, obtener la información del restaurante

      if (!order) {
        throw new Error('Order not found');
      }

      // Obtener los OrderItems relacionados con la orden y popular la información del producto
      const orderItems = await orderItemModel.find({ orderId }).populate({
        path: 'productId', // Popular el campo productId para obtener los detalles del producto
        select: 'name price',
      });

      // Calcular el total de la orden
      const totalAmount = orderItems.reduce(
        (acc, item) => acc + item.quantity * item.price,
        0,
      );

      // Estructura de respuesta que contiene la información necesaria
      return {
        _id: order._id,
        restaurant: order.restaurantId, // Información del restaurante
        user: order.userId, // Información del usuario que emitió la orden
        tableNumber: order.tableNumber || 'N/A',
        createdAt: order.createdAt,
        status: order.status,
        totalAmount,
        products: orderItems.map((item: any) => {
          console.log(item?.productId);
          return {
            productId: item?.productId?._id, // ID del producto
            productName: item?.productId?.name, // Nombre del producto
            quantity: item.quantity,
            price: item.price,
            description: item.description,
            total: item.quantity * item.price, // Total por producto
          };
        }),
      };
    } catch (error) {
      throw new Error(`Error fetching order details: ${error}`);
    }
  }
}

export default OrderService;
