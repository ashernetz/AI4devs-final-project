import { ProductModel } from '../../data/index';
import { RegisterProductDto } from '../../domain/dtos/product/register-product.dto';
import { CustomError } from '../../domain/errors/custom.error';
import { EditProductDto } from '../../domain/dtos/product/edit-product.dto';

class ProductService {
  constructor() {}

  public async registerProduct(registerProductDto: RegisterProductDto) {
    try {
      const product = new ProductModel(registerProductDto);
      await product.save();
      return product;
    } catch (e) {
      console.log(e);
      throw CustomError.internalServerError(`Error creating product ${e}`);
    }
  }

  public async updateProduct(productDto: EditProductDto) {
    try {
      const product = await ProductModel.findById(productDto.productId);
      if (!product) {
        throw CustomError.notFound(
          `Product with id ${productDto.productId} not found`,
        );
      }
      product.name = productDto.name;
      product.description = productDto.description;
      product.price = parseInt(productDto.price);
      product.categoryId = productDto.categoryId;

      return product;
    } catch (e) {
      throw CustomError.internalServerError(`Error updating product ${e}`);
    }
  }

  deleteProduct = async (productId: string) => {
    try {
      const product = await ProductModel.findById(productId);
      if (!product) {
        throw CustomError.notFound(`Product with id ${productId} not found`);
      }
      await product.deleteOne({
        _id: productId,
      });
      return true;
    } catch (e) {
      throw CustomError.internalServerError(`Error deleting product ${e}`);
    }
  };

  public async getAllProducts(restaurantId: string) {
    try {
      const products = await ProductModel.find({
        restaurantId,
      });
      return products;
    } catch (e) {
      throw CustomError.internalServerError(`Error creating product ${e}`);
    }
  }

  public async getProductById(productId: string, restaurantId: string) {
    try {
      const product = await ProductModel.findById({
        _id: productId,
        restaurantId,
      });
      if (!product) {
        throw CustomError.notFound(`Product with id ${productId} not found`);
      }
      return product;
    } catch (e) {
      throw CustomError.internalServerError(`Error getting product ${e}`);
    }
  }
}

export default ProductService;
