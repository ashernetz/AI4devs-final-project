import { InventoryModel } from '../../data/index';
class InventoryService {
  constructor() {}

  async addInventory(order: any) {
    try {
      const inventory = new InventoryModel(order);
      await inventory.save();
      return inventory;
    } catch (e) {
      throw new Error(`Error creating inventory ${e}`);
    }
  }

  async getInventoryByRestaurantId(restaurantId: string) {
    try {
      const inventory = await InventoryModel.find({ restaurantId }).populate(
        'productId',
        'name',
      );
      return inventory;
    } catch (e) {
      throw new Error(`Error getting inventory ${e}`);
    }
  }

  async updateInventoryOnOrder(order: any) {}
}

export default InventoryService;
