import { RestaurantModel, UserModel } from '../../data/index';
import { RegisterRestaurantDto } from '../../domain/dtos/restaurant/register-restaurant.dto';
import { CustomError } from '../../domain/errors/custom.error';
import { UserRole } from '../../data/index';
import { UpdateRestaurantDto } from '../../domain/dtos/restaurant/update-restaurant.dto';
import mongoose from 'mongoose';
const ObjectId = mongoose.Types.ObjectId;
class RestaurantService {
  constructor() {}
  public async registerRestaurant(
    registerRestaurantDto: RegisterRestaurantDto,
  ) {
    const hasRestaurant = await this.hasRestaurant(registerRestaurantDto);
    if (hasRestaurant) {
      throw new Error('Restaurant already exists');
    }

    try {
      const restaurant = new RestaurantModel(registerRestaurantDto);
      await restaurant.save();

      const userRole = new UserRole({
        userId: registerRestaurantDto.ownerId,
        restaurantId: restaurant._id,
        role: 'owner',
      });
      await userRole.save();
      return restaurant;
    } catch (e) {
      console.log(e);
      throw CustomError.internalServerError(`Error creating user ${e}`);
    }
  }

  public async getRestaurantById(id: string) {
    try {
      return await RestaurantModel.findById(id).populate('ownerId', 'name');
    } catch (e) {
      throw CustomError.internalServerError(`Error creating user ${e}`);
    }
  }

  updateRestaurant = async (updateRestaurantDto: UpdateRestaurantDto) => {
    try {
      const restaurant = await RestaurantModel.findById(updateRestaurantDto.id);
      if (!restaurant) {
        throw CustomError.notFound(
          `Restaurant with id ${updateRestaurantDto.id} not found`,
        );
      }
      restaurant.name = updateRestaurantDto.name;
      restaurant.location = updateRestaurantDto.location;
      restaurant.address = updateRestaurantDto.address;
      restaurant.ownerId = new mongoose.Types.ObjectId(
        updateRestaurantDto.ownerId,
      );
      await restaurant.save();
      return restaurant;
    } catch (e) {
      throw CustomError.internalServerError(`Error updating restaurant ${e}`);
    }
  };
  getAllRestaurants = async () => {
    try {
      const restaurants = await RestaurantModel.find().populate(
        'ownerId',
        'name',
      );
      const restaurantsWithEmployeeCount = await Promise.all(
        restaurants.map(async (restaurant) => {
          // Contar cuántos empleados tienen este restaurantId
          const employeeCount = await UserModel.countDocuments({
            restaurantId: restaurant._id,
          });

          // Retornar el restaurante con el conteo de empleados
          return {
            ...restaurant.toObject(), // Convertimos el restaurante a objeto simple
            employeeCount,
          };
        }),
      );
      return restaurantsWithEmployeeCount;
    } catch (e) {
      throw CustomError.internalServerError(`Error creating user ${e}`);
    }
  };

  getByOwnerId = async (ownerId: string) => {
    try {
      return await RestaurantModel.find({ ownerId });
    } catch (e) {
      throw CustomError.internalServerError(`Error creating user ${e}`);
    }
  };

  hasRestaurant = async (registerRestaurantDto: RegisterRestaurantDto) => {
    const restaurant = await RestaurantModel.findOne({
      name: registerRestaurantDto.name,
      location: registerRestaurantDto.location,
      ownerId: registerRestaurantDto.ownerId,
    });
    return Boolean(restaurant);
  };

  deleteRestaurant = async (id: string) => {
    try {
      return await RestaurantModel.findByIdAndDelete(id);
    } catch (e) {
      throw CustomError.internalServerError(`Error creating user ${e}`);
    }
  };
}
export default RestaurantService;
