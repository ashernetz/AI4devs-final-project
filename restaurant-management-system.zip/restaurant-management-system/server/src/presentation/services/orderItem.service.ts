import { RegisterOrderItemDto } from '../../domain/dtos/orderItem/registerOrderItem.dto';
import { CustomError } from '../../domain/errors/custom.error';
import { orderItemModel } from '../../data';

class OrderItemService {
  constructor() {}

  async registerOrderItem(registerOrderItemDto: RegisterOrderItemDto) {
    try {
      const orderItem = new orderItemModel(registerOrderItemDto);
      await orderItem.save();
      return orderItem;
    } catch (e) {
      throw CustomError.internalServerError(`Error creating orderItem ${e}`);
    }
  }

  async getItemsByOrder(orderId: string) {
    try {
      const items = await orderItemModel.find({ orderId });
      return items;
    } catch (e) {
      throw CustomError.internalServerError(`Error getting items ${e}`);
    }
  }

  async deleteOrderItem(orderItemId: string) {
    try {
      const orderItem = await orderItemModel.findById(orderItemId);
      if (!orderItem) {
        throw CustomError.notFound(
          `OrderItem with id ${orderItemId} not found`,
        );
      }
      await orderItem.deleteOne({
        _id: orderItemId,
      });

      return true;
    } catch (e) {
      throw CustomError.internalServerError(`Error deleting orderItem ${e}`);
    }
  }

  async updateOrderItem(orderItemId: string, quantity: number) {
    try {
      const orderItem = await orderItemModel.findById({ _id: orderItemId });
      if (!orderItem) {
        throw CustomError.notFound(
          `OrderItem with id ${orderItemId} not found`,
        );
      }
      orderItem.quantity = quantity;
      await orderItem.save();
      return orderItem;
    } catch (e) {
      throw CustomError.internalServerError(`Error deleting orderItem ${e}`);
    }
  }
}

export default OrderItemService;
