import { Router } from 'express';
import UserController from './controller';
import UserService from '../services/user.service';
import canAddEmployee from '../../middleware/auth/canAddEmployee';

class UserRoutes {
  static get routes(): Router {
    const router = Router();
    const userService = new UserService();
    const controller = new UserController(userService);
    console.log('in here?');
    router.get('/:role', controller.getUsersByRole);
    router.get('/restaurant/:id', controller.getUsersByRestaurant);
    router.post('/details', controller.getUserDetails);
    router.put('/update', controller.updateUser);
    router.post('/login', controller.loginUser);
    router.post('/register', canAddEmployee, controller.registerUser);

    return router;
  }
}

export default UserRoutes;
