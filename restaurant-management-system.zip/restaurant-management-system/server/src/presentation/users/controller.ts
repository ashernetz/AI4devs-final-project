import { Request, Response } from 'express';
import { RegisterUserDto } from '../../domain/dtos/user/register-user.dto';
import { CustomError } from '../../domain/errors/custom.error';
import UserService from '../services/user.service';
import { LoginUserDto } from '../../domain/dtos/user/login-user.dto';
import { EditUserDto } from '../../domain/dtos/user/edit-user.dto';

export default class UserController {
  constructor(public readonly userService: UserService) {}

  private handleError = (error: any, res: Response) => {
    if (error instanceof CustomError) {
      return res.status(error.statusCode).json({ error: error.message });
    }
    return res.status(500).json({ error: error.message });
  };

  registerUser = (req: Request, res: Response) => {
    const { body } = req;
    const registerUserDto = RegisterUserDto.create(body);
    const [error, dto] = registerUserDto;
    if (error) {
      return res.status(400).json({ error });
    }
    console.log('register', dto);
    this.userService
      .registerUser(dto!)
      .then((user: any) => {
        res.json(user);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  updateUser = (req: Request, res: Response) => {
    const { body } = req;
    const editUserDto = EditUserDto.create(body);
    const [error, dto] = editUserDto;
    if (error) {
      return res.status(400).json({ error });
    }
    this.userService
      .updateUser(dto!)
      .then((user: any) => {
        res.json(user);
      })
      .catch((e) => {
        this.handleError(e, res);
      });
  };

  getUsersByRole = (req: Request, res: Response) => {
    const { role } = req.params;
    this.userService
      .getUsersByRole(role)
      .then((users: any) => {
        res.json(users);
      })
      .catch((e) => {
        this.handleError(e, res);
      });
  };

  loginUser = (req: Request, res: Response) => {
    const { body } = req;
    console.log('the body', body);
    const loginUserDto = LoginUserDto.create(body);
    const [error, dto] = loginUserDto;
    if (error) {
      return res.status(400).json({ error });
    }
    this.userService
      .loginUser(dto!)
      .then((user) => {
        console.log('the user', user);
        res.json(user);
      })
      .catch((e) => {
        this.handleError(e, res);
      });
  };

  getUsersByRestaurant = (req: Request, res: Response) => {
    const { id } = req.params;
    this.userService
      .getUsersByRestaurant(id)
      .then((users: any) => {
        res.json(users);
      })
      .catch((e) => {
        this.handleError(e, res);
      });
  };

  getUserDetails = (req: Request, res: Response) => {
    console.log('in the details');
    const { employeeId, role, restaurantId } = req.body;
    console.log('the params', employeeId, role, restaurantId);
    this.userService
      .getUserDetails(employeeId, role, restaurantId)
      .then((user: any) => {
        res.json(user);
      })
      .catch((e) => {
        this.handleError(e, res);
      });
  };
}
