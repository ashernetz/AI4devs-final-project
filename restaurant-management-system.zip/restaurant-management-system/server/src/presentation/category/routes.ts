import { Router } from 'express';
import CategoryController from './controller';
import CategoryService from '../services/category.service';

class CategoryRoutes {
  static get routes(): Router {
    const router = Router();
    const categoryService = new CategoryService();
    const controller = new CategoryController(categoryService);
    router.get('/', controller.getAllCategories);
    router.get('/:id', controller.getCategoryById);
    router.post('/', controller.registerCategory);
    router.patch('/:id', controller.editCategory);
    return router;
  }
}

export default CategoryRoutes;
