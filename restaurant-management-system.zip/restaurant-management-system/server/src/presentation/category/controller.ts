import { Request, Response } from 'express';
import { RegisterCategoryDto } from '../../domain/dtos/category/RegisterCategory.dto';
import { CustomError } from '../../domain/errors/custom.error';
import CategoryService from '../services/category.service';
import { EditCategoryDto } from '../../domain/dtos/category/EditCategory.dto';

export default class CategoryController {
  constructor(public readonly categoryService: CategoryService) {}

  private handleError = (error: any, res: Response) => {
    if (error instanceof CustomError) {
      return res.status(error.statusCode).json({ error: error.message });
    }
    return res.status(500).json({ error: error.message });
  };

  registerCategory = (req: Request, res: Response) => {
    const { body } = req;
    const registerCategoryDto = RegisterCategoryDto.create(body);
    const [error, dto] = registerCategoryDto;
    if (error) {
      return res.status(400).json({ error });
    }
    this.categoryService
      .registerCategory(dto!)
      .then((category: any) => {
        res.json(category);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  editCategory = (req: Request, res: Response) => {
    const { body } = req;
    const { id } = req.params;
    const registerCategoryDto = EditCategoryDto.create({
      ...body,
      id: id.toString(),
    });
    const [error, dto] = registerCategoryDto;
    if (error) {
      return res.status(400).json({ error });
    }
    this.categoryService
      .editCategory(dto!)
      .then((category: any) => {
        res.json(category);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  getAllCategories = (req: Request, res: Response) => {
    this.categoryService
      .getAllCategories()
      .then((categories: any) => {
        res.json(categories);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  getCategoryById = (req: Request, res: Response) => {
    const { id } = req.params;
    this.categoryService
      .getCategoryById(id.toString())
      .then((category: any) => {
        res.json(category);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };
}
