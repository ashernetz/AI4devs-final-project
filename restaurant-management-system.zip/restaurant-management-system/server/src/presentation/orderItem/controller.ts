import { Request, Response } from 'express';
import { RegisterOrderItemDto } from '../../domain/dtos/orderItem/registerOrderItem.dto';
import { CustomError } from '../../domain/errors/custom.error';
import OrderItemService from '../services/orderItem.service';
export default class OrderItemController {
  constructor(private orderItemService: OrderItemService) {}

  private handleError = (error: any, res: Response) => {
    if (error instanceof CustomError) {
      return res.status(error.statusCode).json({ error: error.message });
    }
    return res.status(500).json({ error: error.message });
  };

  registerOrderItem = (req: Request, res: Response) => {
    const { body } = req;
    const registerOrderItemDto = RegisterOrderItemDto.create({
      ...body,
      quantity: parseInt(body.quantity),
      price: parseInt(body.price),
    });
    const [error, dto] = registerOrderItemDto;
    if (error) {
      return res.status(400).json({ error });
    }
    console.log('dto', dto);
    this.orderItemService
      .registerOrderItem(dto!)
      .then((orderItem) => {
        res.json(orderItem);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  getItemsByOrder = (req: Request, res: Response) => {
    const { orderId } = req.body;
    this.orderItemService
      .getItemsByOrder(orderId)
      .then((items: any) => {
        res.json(items);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  updateOrderItem = (req: Request, res: Response) => {
    const { orderItemId } = req.params;
    const {  quantity } = req.body;
    this.orderItemService
      .updateOrderItem(orderItemId, quantity)
      .then((orderItem) => {
        res.json(orderItem);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  deleteOrderItem = (req: Request, res: Response) => {
    const { id } = req.params;
    this.orderItemService
      .deleteOrderItem(id)
      .then((response) => {
        res.json(response);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };
}
