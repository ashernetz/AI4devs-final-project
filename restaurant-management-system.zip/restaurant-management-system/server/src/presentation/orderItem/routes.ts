import { Router } from 'express';
import OrderItemService from '../services/orderItem.service';
import OrderItemController from './controller';

class OrderItemRoutes {
  static get routes(): Router {
    const router = Router();
    const orderItemService = new OrderItemService();
    const controller = new OrderItemController(orderItemService);
    router.get('/', controller.getItemsByOrder);
    router.post('/', controller.registerOrderItem);
    router.patch('/:orderItemId', controller.updateOrderItem);
    router.delete('/:orderItemId', controller.deleteOrderItem);
    return router;
  }
}

export default OrderItemRoutes;
