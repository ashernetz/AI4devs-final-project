import { Router } from 'express';
import OrdersController from './controller';
import OrderService from '../services/order.service';

class OrderRoutes {
  static get routes(): Router {
    const router = Router();

    const orderService = new OrderService();
    const orderController = new OrdersController(orderService);
    router.get('/', orderController.getAllOrders);
    router.get(
      '/restaurant/:restaurantId',
      orderController.getOrdersByRestaurant,
    );
    router.get('/table', orderController.getOrdersByTable);
    router.get('/status', orderController.getOrdersByStatus);
    router.get('/details/:orderId', orderController.getOrderDetails);
    router.post('/', orderController.registerOrder);
    router.patch('/status', orderController.updateOrderStatus);
    router.delete('/', orderController.deleteOrder);
    return router;
  }
}

export default OrderRoutes;
