import { Request, Response } from 'express';
import { CustomError } from '../../domain/errors/custom.error';
import OrderService from '../services/order.service';
import { RegisterOrderDto } from '../../domain/dtos/order/RegisterOrder.dto';

export default class OrdersController {
  constructor(public readonly orderService: OrderService) {}

  private handleError = (error: any, res: Response) => {
    if (error instanceof CustomError) {
      return res.status(error.statusCode).json({ error: error.message });
    }
    return res.status(500).json({ error: error.message });
  };

  registerOrder = (req: Request, res: Response) => {
    const { body } = req;
    const registerOrderDto = RegisterOrderDto.create({
      ...body,
      totalAmount: 0,
    });
    const [error, dto] = registerOrderDto;
    this.orderService
      .registerOrder(dto!)
      .then((order) => {
        res.json(order);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  getOrdersByRestaurant = (req: Request, res: Response) => {
    const { restaurantId } = req.params;
    this.orderService
      .getOrdersByRestaurant(restaurantId)
      .then((orders: any) => {
        res.json(orders);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  getAllOrders = (req: Request, res: Response) => {
    this.orderService
      .getAllOrders()
      .then((orders) => {
        res.json(orders);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };
  getOrdersByTable = (req: Request, res: Response) => {
    const { tableNumber, restaurantId } = req.body;
    this.orderService
      .getOrdersByTable(tableNumber, restaurantId)
      .then((orders: any) => {
        res.json(orders);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  getOrdersByStatus = (req: Request, res: Response) => {
    const { status, restaurantId } = req.body;
    this.orderService
      .getOrdersByStatus(status, restaurantId)
      .then((orders: any) => {
        res.json(orders);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  updateOrderStatus = (req: Request, res: Response) => {
    const { status, orderId } = req.body;
    this.orderService
      .updateOrderStatus(orderId, status)
      .then((order: any) => {
        res.json(order);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  deleteOrder = (req: Request, res: Response) => {
    const { orderId } = req.params;
    this.orderService
      .deleteOrder(orderId)
      .then((order: any) => {
        res.json(order);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };

  getOrderDetails = (req: Request, res: Response) => {
    const { orderId } = req.params;
    this.orderService
      .getOrderDetails(orderId)
      .then((order: any) => {
        res.json(order);
      })
      .catch((error: Error) => {
        this.handleError(error, res);
      });
  };
}
